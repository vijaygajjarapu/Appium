package com.tmbc;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.tmbc.stepDefinitions.BrowserConfig;

public class Helper {
	public static WebDriver driver = BrowserConfig.driver;
	public Helper(){
		
	}
	public void Webdriver_waitToClick(WebElement element) {
		try {
			WebDriverWait wait = new WebDriverWait(driver, 180);
			wait.until(ExpectedConditions.elementToBeClickable(element));
		} catch (Exception e) {
		}
	}

	public void Webdriver_waitToVisible(WebElement element) {
		try {
			WebDriverWait wait = new WebDriverWait(driver, 300);
			wait.until(ExpectedConditions.visibilityOf(element));
		} catch (Exception e) {
		}
	}
}
