package com.tmbc.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.tmbc.Helper;
import com.tmbc.stepDefinitions.BrowserConfig;

public class TeamManagememtPage {


	public static WebDriver driver = BrowserConfig.driver;
	private Helper helper; 

	public TeamManagememtPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		helper = new Helper();
	}

	@FindBy(xpath = "//div[text()='Leader Tools']")
	public WebElement leaderTools;
	
	@FindBy(xpath = "//div[text()='To-Do']")
	public WebElement todo;

	@FindBy(xpath = "//span[text()='Team Management']")
	public WebElement teamManagementLink;
    
	@FindBy(xpath = "//a[contains(text(),'Create a New Team')]")
	public WebElement createNewTeamBtn;
	
	@FindBy(id = "teamName")
	public WebElement teamNameTxtBx;

	@FindBy(xpath = "//i[@class='fa fa-caret-down']")
	public WebElement phoneTypeDrpDwn;
	
	/*@FindBy(xpath = "//label[text()='Android']/../div")
	public WebElement andriodType;*/
	
	@FindBy(xpath = "//label[text()='Android']")
	public WebElement andriodType;
	
	@FindBy(xpath = "//label[text()='iOS']/../div")
	public WebElement iosType;
	
	@FindBy(xpath = "//label[text()='Windows']/../div")
	public WebElement windowsType;
	
	@FindBy(xpath = "//button[text()='Create team']")
	public WebElement createTeamBtn;
	
	@FindBy(xpath = "//a[contains(text(),'Invite Team Members')]")
	public WebElement inviteTeamMembers;
	
	@FindBy(xpath = "//button[@class='so-close-bold larger-hit']")
	public WebElement closeMark;
	
	@FindBy(xpath = "//button[@class='so-back back-arrow larger-hit']")
	public WebElement backBtn;
	
	@FindBy(xpath = "//div[text()='Test Mobile Team 4']")
	public WebElement createdTeam;
	
	@FindBy(xpath = "//button[@class='so-back back-arrow larger-hit']/../following-sibling::div/i")
	public WebElement teamOption;	
	
	@FindBy(xpath = "//*[text()='Delete Team']")
	public WebElement deleteTeam;
	
	@FindBy(xpath = "//*[text()='Confirm']")
	public WebElement confirmBtn;
	

	public void navigateToTeamManagement(String emailId) {
		helper.Webdriver_waitToClick(leaderTools);
		leaderTools.click();
		helper.Webdriver_waitToClick(teamManagementLink);
		teamManagementLink.click();
	}
	
	public void clickOnCreateANewTeam() {
		helper.Webdriver_waitToClick(createNewTeamBtn);
		createNewTeamBtn.click();		
	}

	public void createNewTeam(String teamName) {
		helper.Webdriver_waitToClick(teamNameTxtBx);
		teamNameTxtBx.sendKeys(teamName);
		helper.Webdriver_waitToClick(phoneTypeDrpDwn);
		phoneTypeDrpDwn.click();
		helper.Webdriver_waitToClick(andriodType);
		andriodType.click();
		helper.Webdriver_waitToClick(createTeamBtn);
		createTeamBtn.click();
		helper.Webdriver_waitToClick(inviteTeamMembers);
		inviteTeamMembers.click();
		helper.Webdriver_waitToClick(inviteTeamMembers);
		inviteTeamMembers.click();
		helper.Webdriver_waitToClick(closeMark);
		closeMark.click();
		helper.Webdriver_waitToClick(leaderTools);
		leaderTools.click();
		/*helper.Webdriver_waitToClick(backBtn);
		backBtn.click();
		helper.Webdriver_waitToClick(backBtn);
		backBtn.click();*/
	}

	public void deleteTeam() {
		helper.Webdriver_waitToClick(createdTeam);
		createdTeam.click();
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		helper.Webdriver_waitToClick(teamOption);
		teamOption.click();
		helper.Webdriver_waitToClick(deleteTeam);
		deleteTeam.click();
		helper.Webdriver_waitToClick(confirmBtn);
		confirmBtn.click();
		
	}


}
