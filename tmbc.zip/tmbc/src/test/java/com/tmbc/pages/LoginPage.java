package com.tmbc.pages;

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.tmbc.Helper;
import com.tmbc.stepDefinitions.BrowserConfig;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class LoginPage {

	public static WebDriver driver = BrowserConfig.driver;
	private Helper helper; 

	public LoginPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		helper = new Helper();
	}

	@FindBy(id = "email")
	public WebElement emailTxtBx;

	@FindBy(xpath = "//button[@class='btn btn-login']")
	public WebElement nextBtn;
    
	@FindBy(id = "password")
	public WebElement passwordTxtBx;
	
	@FindBy(xpath = "//button[@name='login']")
	public WebElement loginBtn;

	@FindBy(xpath = "//a[contains(text(),'My Teams')]")
	public WebElement myTeamsDashBoards;
	
	@FindBy(xpath = "//div[@class='avatar']")
	public WebElement moreMenu;
	
	@FindBy(xpath = "//a[contains(text(),'Log Out')]/div")
	public WebElement logoutBtn;
	
	@FindBy(xpath = "//a[text()='Tap here to log back in.']")
	public WebElement loggedOutScreen;
	
	@FindBy(xpath = "//android.widget.TextView[@text='App']")
	public WebElement appMenu;
	
	@FindBy(xpath = "//android.widget.TextView[@text='Activity']")
	public WebElement activityMenu;
	
	@FindBy(xpath = "//android.widget.TextView[@text='Hello World']")
	public WebElement helloWorld;
	
	//android.widget.Button[@text=’5′]
	
	@FindBy(xpath = "//android.widget.Button[@text='5']")
	public WebElement one;
	
	@FindBy(xpath = "//android.widget.Button[@text='5']")
	public WebElement two;
	
	public void calc() {
	//switchToWebView();
	/*	helper.Webdriver_waitToClick(appMenu);
		appMenu.click();
		helper.Webdriver_waitToClick(activityMenu);
		activityMenu.click();
		helper.Webdriver_waitToClick(helloWorld);
		helloWorld.click();
		//switchToWebView();*/
		one.click();
		two.click();
	}
	public void navigateToHello() {
		//switchToWebView();
		helper.Webdriver_waitToClick(appMenu);
		appMenu.click();
		helper.Webdriver_waitToClick(activityMenu);
		activityMenu.click();
		helper.Webdriver_waitToClick(helloWorld);
		helloWorld.click();
	}
	
	public void switchToWebView() {
		// Switching to webview
		try {
			Set<String> contextNames = ((AppiumDriver<MobileElement>) driver).getContextHandles();
			for (String contextName : contextNames) {
				System.out.println(contextNames); // prints out something like [NATIVE_APP, WEBVIEW_<APP_PKG_NAME>]
			}
			((AppiumDriver<MobileElement>) driver).context((String) contextNames.toArray()[1]); // set context to
																								// WEBVIEW_<APP_PKG_NAME>
		} catch (Exception e) {

		}
	}

	public void enterEmail(String emailId) {
		helper.Webdriver_waitToClick(emailTxtBx);
		emailTxtBx.sendKeys(emailId);
	}
	
	public void clickOnNextButton() {
		helper.Webdriver_waitToClick(nextBtn);
		nextBtn.click();
	}

	public void enterPassword(String password) {
		helper.Webdriver_waitToClick(passwordTxtBx);
		passwordTxtBx.sendKeys(password);
	}

	public void clickLogin() {
		helper.Webdriver_waitToClick(loginBtn);
		loginBtn.click();
		helper.Webdriver_waitToVisible(myTeamsDashBoards);
		
	}

	public void clickOnMoreMenu() {
		helper.Webdriver_waitToClick(moreMenu);
		moreMenu.click();
	}
	public void logout() {
		helper.Webdriver_waitToClick(logoutBtn);
		logoutBtn.click();
		helper.Webdriver_waitToVisible(loggedOutScreen);
	}
	
}
