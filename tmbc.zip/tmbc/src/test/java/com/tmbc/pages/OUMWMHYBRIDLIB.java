/*package com.tmbc.pages;

package com.oracle.utilities.mwm.lib;

import java.awt.Robot;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Point;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.oracle.utilities.core.lib.OUTSPCORELIB;
import com.oracle.utilities.core.lib.WSCOMMONLIB;
import com.oracle.utilities.core.plugin.FunctionalTestScript;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileBy;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.ios.IOSElement;
import io.appium.java_client.remote.MobileCapabilityType;
import io.appium.java_client.windows.WindowsDriver;
import io.appium.java_client.windows.WindowsElement;

//import lib.oracle.outsp.core.UIObject; //MWM UI Objects: Static Type


* @Description: MWM automation on Android, IOS, and Chrome MCP's
* 
 * @Issues: 
 * https://github.com/Microsoft/WinAppDriver/issues/42
* https://github.com/Microsoft/WinAppDriver/issues/69
* 
 

public class OUMWMHYBRIDLIB extends FunctionalTestScript {

	String InfoDescription = "", dispatchedTaskID = "";
	final String CONST_PASSED = "Passed";
	final String CONST_FAILED = "Failed";

	//static private WebDriver driver; // 16-Mar-2016: Added Static Generic driver
	static private String DEVICE_TYPE; // This will set the DEVICE_TYPE: ANDROID, IOS, CHROME => To Handle Application
										// specific Logic

	WSCOMMONLIB wSCOMMONLIB = new WSCOMMONLIB();
	OUTSPCORELIB oUTSPCORELIB = new OUTSPCORELIB();

	
	 * static public WindowsDriver CalculatorSession; // Windows-10 POC static
	 * public WebElement CalculatorResult;
	 

	// @FunctionLibrary("WSCOMMONLIB") lib.oracle.outsp.core.WSCOMMONLIB
	// wSCOMMONLIB;
	// @FunctionLibrary("OUTSPCORELIB") lib.oracle.outsp.core.OUTSPCORELIB
	// oUTSPCORELIB;

	*//**
	 * Add code to be executed each iteration for this virtual user.
	 *//*
	public void run() throws Exception {

	}

	public static String executeCommand(String cmd) {
		String commandresponse = "";
		try {
			Runtime run = Runtime.getRuntime();
			Process proc = run.exec(cmd);
			BufferedReader stdInput = new BufferedReader(new InputStreamReader(proc.getInputStream()));

			BufferedReader stdError = new BufferedReader(new InputStreamReader(proc.getErrorStream()));

			String response = null;
			while ((response = stdInput.readLine()) != null) {
				if (response.length() > 0) {
					commandresponse = commandresponse + response;
				}
			}

			while ((response = stdError.readLine()) != null) {
				commandresponse = commandresponse + response;

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		// System.out.println(commandresponse);
		return commandresponse;
	}
	
	@SuppressWarnings("unchecked")
	public String AndroidMCP_startRemoteDriver() throws Exception {

		String gStrAndroidOSVersion = getVariables.get("gStrAndroidOSVersion");
		String gStrAndroidDeviceName = getVariables.get("gStrAndroidDeviceName");
		String gStrAndroidDeviceUID = getVariables.get("gStrAndroidDeviceUID");
		String gStrAndroidBuildPath = getVariables.get("gStrAndroidBuildPath");
		String gStrAndroidMCPRemoteNodeURL = getVariables.get("gStrAndroidMCPRemoteNodeURL");

		// try {
		// HybridApplication capabilities: This is not required for the APK installation
		String mwmAppPackageName = "com.oraclecorp.internal.mwm.runtime";
		String mwmAppActivityName = "com.oraclecorp.internal.mwm.runtime.HybridRuntimeActivity";
		
		
		//
		// String mwmAppPackageName="com.splwg.base.android";
		// String mwmAppActivityName="com.splwg.base.android.MCPRuntimeStartupActivity";

		DEVICE_TYPE = "ANDROID";
		info("DEVICE-TYPE is set for ANDROID.");

		String osVersion = gStrAndroidOSVersion; // 6.0
		// String deviceName="emulator"; //emulator
		String deviceName = gStrAndroidDeviceName; // REAL DEVICE
		String deviceUID = gStrAndroidDeviceUID;
		// String deviceUID="emulator-5554"; //For Device and emulator(optional)
		String androidBuildPath = gStrAndroidBuildPath;
		String androidNodeUrl = gStrAndroidMCPRemoteNodeURL;

		info("Android Latest Build path: " + androidBuildPath);

		DesiredCapabilities capabilities = new DesiredCapabilities();
		capabilities.setCapability("noReset", "true");
		capabilities.setCapability("fullReset", "false");
		// capabilities.setCapability("automationName","Driving MWM with Appium");
		capabilities.setCapability("platformName", "Android");
		// capabilities.setCapability("VERSION", osVersion);
		capabilities.setCapability("deviceName", deviceName);
		if (deviceUID != null)
			capabilities.setCapability(MobileCapabilityType.UDID, deviceUID);
		capabilities.setCapability(MobileCapabilityType.APP, androidBuildPath);
		// capabilities.setCapability(MobileCapabilityType.APP_PACKAGE,
		// mwmAppPackageName);
		// capabilities.setCapability(MobileCapabilityType.APP_ACTIVITY,
		// mwmAppActivityName);
		capabilities.setCapability("appPackage", mwmAppPackageName);
		capabilities.setCapability("appActivity", mwmAppActivityName);
		capabilities.setCapability("newCommandTimeout", 2147482);
		capabilities.setCapability("unicodeKeyboard", true);
		capabilities.setCapability("resetKeyboard", true);

		String cmd = "adb shell getprop ro.build.version.release";
		String osVersions = executeCommand(cmd);

		if (osVersions.contains("7")) {
			// uninstall io.appium.settings
			cmd = "adb uninstall  io.appium.settings";
			executeCommand(cmd);
			// uninstall io.appium.unlock
			cmd = "adb uninstall  io.appium.unlock";
			executeCommand(cmd);
		}
		driver = new AndroidDriver <MobileElement> (new URL(androidNodeUrl), capabilities);		
		driver.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		Thread.sleep(10000);

		// ((AppiumDriver<MobileElement>) driver).resetApp();
		info("Application got Reset. Application Data got Erased.");
		
		 * //Test Code Thread.sleep(2000); ((AppiumDriver<MobileElement>)
		 * driver).getContextHandles(); Thread.sleep(1000);
		 * ((AppiumDriver<MobileElement>) driver).getContextHandles();
		 * Thread.sleep(1000); ((AppiumDriver<MobileElement>)
		 * driver).context("WEBVIEW_com.oraclecorp.internal.mwm.runtime");
		 * //((AppiumDriver<MobileElement>)
		 * driver).context(((AppiumDriver<MobileElement>)
		 * driver).getContextHandles().toArray()[1].toString()); Thread.sleep(1000);
		 * info("Current Context:" + ((AppiumDriver<MobileElement>)
		 * driver).getContext()); Thread.sleep(1000);
		 * info("Before clicking accept button in test code");
		 * driver.findElement(By.id("acceptbutton")).click();
		 * info("After clicking accept button in test code");
		 

		return "N";
		// } catch (Exception e) {
		// fail(e.getMessage());
		// InfoDescription = e.toString();
		// logComments(
		// InfoDescription,
		// CONST_FAILED);
		// return "N";
		// }
	}

	@SuppressWarnings("unchecked")
	public String MobileMCP_switchToDebugContext() throws Exception {
		try {
			Thread.sleep(1000);
			((AppiumDriver<MobileElement>) driver).getContextHandles();
			Thread.sleep(1000);
			((AppiumDriver<MobileElement>) driver).getContextHandles();
			Thread.sleep(1000);
			// WEBVIEW_
			((AppiumDriver<MobileElement>) driver).context("WEBVIEW_com.oraclecorp.internal.mwm.runtime");
			// ((AppiumDriver<MobileElement>) driver).context(((AppiumDriver<MobileElement>)
			// driver).getContextHandles().toArray()[1].toString());
			Thread.sleep(1000);
			info("Current Context:" + ((AppiumDriver<MobileElement>) driver).getContext());
			return "N";
		} catch (Exception e) {
			fail(e.getMessage());
			InfoDescription = e.toString();
			logComments(InfoDescription, CONST_FAILED);
			return "N";
		}
	}

	public String MobileMCP_selectTerms() throws Exception {
		try {
			System.out.println("Entered into Select Terms 1");
			info("Entered into Select Terms");
			Boolean selection = true;

			Thread.sleep(2000);
			WebElement AcceptButton = driver.findElement(By.id("acceptbutton"));

			
			 * WebElement AcceptButton = (new WebDriverWait(driver,
			 * 100)).until(ExpectedConditions.presenceOfElementLocated(By.id("acceptbutton")
			 * )); info("After Selecting the accept button webelement"); Thread.sleep(1000);
			 * //(new WebDriverWait(driver,
			 * 100)).until(ExpectedConditions.visibilityOf(AcceptButton));
			 * info("Accept Button is visible in the page"); Thread.sleep(1000); //(new
			 * WebDriverWait(driver,
			 * 100)).until(ExpectedConditions.elementToBeClickable(AcceptButton));
			 
			if (selection == true) {
				AcceptButton.click();
				info("Accept Button is Clicked");
			}
			return "N";
		} catch (Exception e) {
			fail(e.getMessage());
			InfoDescription = e.toString();
			logComments(InfoDescription, CONST_FAILED);
			return "N";
		}
	}

	public String MobileMCP_applicationUrl() throws Exception {
		String Url = getVariables.get("gStrMobileDeploymentURL");
		String userName = getVariables.get("gStrApplicationUserName");
		String password = decrypt(getVariables.get("gStrApplicationUserPassword"));

		// info("Entered into application url function");
		// Thread.sleep(2000);
		// driver.findElement(MobileBy.xpath("//a[@id='startupMenuButton']")).click();
		// Thread.sleep(2000);
		// driver.findElement(MobileBy.xpath("//div[@id='startupMenu']//li[text()='Language']/parent::ul")).click();
		try {
			info("Entered into application url function");
			// Thread.sleep(2000);
			// driver.findElement(MobileBy.xpath("//a[@id='startupMenuButton']")).click();
			// Thread.sleep(2000);
			// driver.findElement(MobileBy.xpath("//div[@id='startupMenu']//li[text()='Language']/parent::ul"));

			WebElement appUrl = driver.findElement(By.id("urlInput"));

			// WebElement appUrl = (new WebDriverWait(driver,
			// 60)).until(ExpectedConditions.presenceOfElementLocated(By.id("urlInput")));
			// (new WebDriverWait(driver,
			// 100)).until(ExpectedConditions.visibilityOf(appUrl));
			info("Application URL page is visible");
			Thread.sleep(1000);
			appUrl.sendKeys(Url);
			// This Fields are recently added
			
			driver.findElement(By.id("username")).sendKeys(userName);
			driver.findElement(By.id("password")).sendKeys(password);
			Thread.sleep(2000);
			WebElement downloadButton = driver.findElement(By.id("downloadButton"));
			downloadButton.click();
			info("Download button is clicked");

			//String loginPage = "//input[@id='mdtTag']/ancestor::li/label[text()='MDT Tag']";
			//String loginPage = "//label[text()='MDT Tag']";
			 Thread.sleep(3000);
			//Webdriver_waitToVisible(loginPage);
			// Thread.sleep(35000);
			return "N";
		} catch (Exception e) {
			fail(e.getMessage());
			InfoDescription = e.toString();
			logComments(InfoDescription, CONST_FAILED);
			return "N";
		}
	}

	public void switchToWebView() {
		// Switching to webview
		try {
			Set<String> contextNames = ((AppiumDriver<MobileElement>) driver).getContextHandles();
			for (String contextName : contextNames) {
				System.out.println(contextNames); // prints out something like [NATIVE_APP, WEBVIEW_<APP_PKG_NAME>]
			}
			((AppiumDriver<MobileElement>) driver).context((String) contextNames.toArray()[1]); // set context to
																								// WEBVIEW_<APP_PKG_NAME>
		} catch (Exception e) {

		}
	}
	
	//Switch to windows
	public void switchToWebWindow() {
		// Switching to webview
		try {
			String handle= driver.getWindowHandle();
			System.out.println(handle);
			Set handles = driver.getWindowHandles();
			System.out.println(handles);
			
			for (String handle1 : driver.getWindowHandles()) {				 
		          System.out.println(handle1);		 
		          driver.switchTo().window(handle1);		 
		          }
		} catch (Exception e) {

		}
	}

	// Validate MDT
	public String HybridMCP_validateMDT(String mdtTag) throws Exception {
		String userName = getVariables.get("gStrApplicationUserName");
		String password = decrypt(getVariables.get("gStrApplicationUserPassword"));
		try {
			info("Filling Login Form with-> USER: " + userName + ", PASS: " + password + ", MDT: " + mdtTag);
			String loginPage = "//input[@id='mdtTag']/ancestor::li/label[text()='MDT Tag']";
			// String loginPage = "//label[text()='MDT Tag']";
			// Thread.sleep(3000);
			Webdriver_waitToVisible(loginPage);
			// WebElement MdtTag = driver.findElement(By.id("mdtTag"));
			info("Login page is visible");
			Thread.sleep(1000);
			driver.findElement(By.xpath("//label[@id='mdtTag-label']/../div")).click();
			driver.findElement(By.xpath("//label[@id='mdtTag-label']/../div/input")).click();
			driver.findElement(By.xpath("//label[@id='mdtTag-label']/../div/input")).sendKeys(mdtTag);
			driver.findElement(By.id("username")).sendKeys(userName);
			driver.findElement(By.id("password")).sendKeys(password);
			info("Clicking the LOGIN button");
			driver.findElement(By.xpath("//a[@role='button']/span")).click();
			info("LOGIN button is Clicked");
			Thread.sleep(5000);
			switchToWebView();
			String err = driver
					.findElement(MobileBy.xpath("//div[@id='alertPopup']//span[contains(text(),'Invalid MDT TAG')]"))
					.getText();
			// String erar = driver.findElement(By.xpath("//*[@content-desc='Invalid MDT
			// TAG.' and @index='0']")).getText();
			Webdriver_waitToVisible("//div[@id='alertPopup']//span[contains(text(),'Invalid MDT TAG')]");
			System.out.println("Error Message is  " + err);
			if (err.equalsIgnoreCase("Invalid MDT TAG.")) {
				info(err + " message is displayed");
			} else
				info(err + " message is not displayed");
			driver.findElement(By.xpath("//div[@id='alertPopup']//a")).click();
			return "N";
		} catch (Exception e) {
			fail(e.getMessage());
			InfoDescription = e.toString();
			logComments(InfoDescription, CONST_FAILED);
			return "N";
		}
	}

	public String MobileMCP_loginPage(String mdtTag) throws Exception {
		String userName = getVariables.get("gStrApplicationUserName");
		String password = decrypt(getVariables.get("gStrApplicationUserPassword"));
		try {
			info("Filling Login Form with-> USER: " + userName + ", PASS: " + password + ", MDT: " + mdtTag);
			//String loginPage = "//input[@id='mdtTag']";
			String loginPage = "//input[@id='mdtTag']/ancestor::li/label[text()='MDT Tag']";
			Thread.sleep(3000);
			System.out.println("waiting");
			Webdriver_waitToClick(loginPage);
			System.out.println("started Immediately");
			// WebElement MdtTag = driver.findElement(By.id("mdtTag"));
			info("Login page is visible");
			Thread.sleep(60000);

			driver.findElement(MobileBy.xpath("//label[@id='mdtTag-label']/../div")).click();
			driver.findElement(MobileBy.xpath("//label[@id='mdtTag-label']/../div/input")).click();
			driver.findElement(MobileBy.xpath("//label[@id='mdtTag-label']/../div/input")).sendKeys(mdtTag);
			;
			// MdtTag.sendKeys(mdtTag);//changing
			// MdtTag.sendKeys(mdtTag);// changing
			driver.findElement(By.id("username")).sendKeys(userName);
			driver.findElement(By.id("password")).sendKeys(password);
			// Implementing Knockout.js bindings : To solve the issue of IOS Simulator
			
			 * JavascriptExecutor js = (JavascriptExecutor) driver;
			 * js.executeScript("ouml.App.getPageContext().viewModel.mdtTag('"+mdtTag+"');")
			 * ; js.executeScript("ouml.App.getPageContext().viewModel.username('"+userName+
			 * "');");
			 * js.executeScript("ouml.App.getPageContext().viewModel.password('"+password+
			 * "');");
			 
			info("Clicking the LOGIN button");
			// Thread.sleep(2000);
			// String loginButton = ""
			driver.findElement(By.xpath("//a[@role='button']/span")).click();

			Thread.sleep(4000);
			// driver.findElement(By.xpath("//android.widget.Button[@content-desc =
			// 'Login']")).click();
			info("LOGIN button is Clicked");
			return "N";
		} catch (Exception e) {
			fail(e.getMessage());
			InfoDescription = e.toString();
			logComments(InfoDescription, CONST_FAILED);
			return "N";
		}
	}

	public String MobileMCP_passwordValidation(String mdtTag) throws Exception {
		String userName = getVariables.get("gStrApplicationUserName");
		String password = decrypt(getVariables.get("gStrApplicationUserPassword"));
		try {
			String expectedErrorMessage = "Authentication Failed - Invalid username or password";
			info("Filling Login Form with-> USER: " + userName + ", PASS: " + password + ", MDT: " + mdtTag);

			WebElement MdtTag = driver.findElement(By.id("mdtTag"));
			info("Login page is visible");
			// Thread.sleep(1000);
			MdtTag.sendKeys("VG42226");
			driver.findElement(By.id("username")).sendKeys(userName);
			driver.findElement(By.id("password")).sendKeys(password + "1");
			// Thread.sleep(1000);
			Webdriver_waitToClick("//a[@role='button']/span");
			info("Clicking the LOGIN button");
			driver.findElement(By.xpath("//a[@role='button']/span")).click();
			info("LOGIN button is Clicked");
			// Thread.sleep(5000);
			String errorMessage = "//div[@id='alertPopup']//span[contains(text(),'Authentication Failed - Invalid username or password')]";
			Webdriver_waitToClick(errorMessage);
			String actualErrorMessage = driver.findElement(MobileBy.xpath(
					"//div[@id='alertPopup']//span[contains(text(),'Authentication Failed - Invalid username or password')]"))
					.getText();
			System.out.println("Error Message is  " + actualErrorMessage);
			if (actualErrorMessage.equalsIgnoreCase(expectedErrorMessage)) {
				info(expectedErrorMessage + " message is displayed");
			} else
				info(expectedErrorMessage + " message is not displayed");
			driver.findElement(By.xpath("//div[@id='alertPopup']//span[contains(text(),'Invalid MDT TAG')]")).click();
			return "N";
		} catch (Exception e) {
			fail(e.getMessage());
			InfoDescription = e.toString();
			logComments(InfoDescription, CONST_FAILED);
			return "N";
		}
	}

	public String ChromeMCP_loginPage(String hardwareID, String mdtTag) throws Exception {
		String userName = getVariables.get("gStrApplicationUserName");
		String password = decrypt(getVariables.get("gStrApplicationUserPassword"));
		try {
			Thread.sleep(10000);
			info("before the if condition- Nagesh");
			info("Filling Login Form with-> USER: " + userName + ", PASS: " + password + ", HARDWARE_ID: " + hardwareID
					+ ", MDT: " + mdtTag);
			WebElement MdtTag = (new WebDriverWait(driver, 70))
					.until(ExpectedConditions.presenceOfElementLocated(By.id("mdtTag")));
			(new WebDriverWait(driver, 100)).until(ExpectedConditions.visibilityOf(MdtTag));
			info("Login page is visible");
			Thread.sleep(10000);

			
			 * Actions actions = new Actions(driver); Robot robot = new Robot();
			 * robot.mouseMove(50,50); actions.click().build().perform();
			 * robot.mouseMove(200,70); actions.click().build().perform();
			 * Thread.sleep(10000);
			 
			
			 * if (driver.findElement(By.id("alertPopup-popup")).isDisplayed()) {
			 * driver.findElement(By.id("alertPopup-popup")).click(); } else {
			 * info("Nagesh- not displayed popup screen"); }
			 
			MdtTag.sendKeys(mdtTag);
			driver.findElement(By.id("username")).sendKeys(userName);
			info("Username button is visible");
			driver.findElement(By.id("password")).sendKeys(password);
			driver.findElement(By.id("hardwareId")).sendKeys(hardwareID);
			Thread.sleep(2000);
			info("Clicking the LOGIN button");
			driver.findElement(By.xpath("//a[@role='button']/span")).click();
			info("LOGIN button is Clicked");
			return "N";
		} catch (Exception e) {
			fail(e.getMessage());
			InfoDescription = e.toString();
			logComments(InfoDescription, CONST_FAILED);
			return "N";
		}
	}

	public String HybridMCP_selectDeployment(String deploymentName) throws Exception {
		try {
			info("Clicking the Deployment of Type: " + deploymentName);
			Thread.sleep(20000);

			if (driver.findElement(By.xpath("//span[text()='REST DEPLOYMENT']")).isDisplayed())

			// if
			// (driver.findElement(By.xpath("//a//span[text()='"+deploymentName+"']")).isDisplayed())

			{
				// WebElement deployButton =
				// driver.findElement(By.xpath("//a//span[text()='"+deploymentName+"']"));
				// WebElement deployButton =
				// driver.findElement(By.xpath("//android.view.View[@content-desc = 'REST
				// DEPLOYMENT ']"));
				WebElement deployButton = driver.findElement(By.xpath("//span[text()='REST DEPLOYMENT']"));
				deployButton.click();

				Thread.sleep(40000);
				info(deploymentName + " button is Clicked");
				return "N";

			}

			return "N";
			
			 * WebElement deployButton = (new WebDriverWait(driver, 20))
			 * .until(ExpectedConditions.presenceOfElementLocated(By.xpath(
			 * "//a//span[text()='"+deploymentName+"']")));
			 * info("Deployment Button is present in the page");
			 
				 * (new WebDriverWait(driver, 100))
				 * .until(ExpectedConditions.visibilityOf(deployButton));
				 * info("Deployment Button is visible in the page"); // Thread.sleep(1000); (new
				 * WebDriverWait(driver, 100))
				 * .until(ExpectedConditions.elementToBeClickable(deployButton));
				 

		} catch (Exception e) {
			fail(e.getMessage());
			InfoDescription = e.toString();
			logComments(InfoDescription, CONST_FAILED);
			return "N";
		}
	}

	public String HybridMCP_startShift() throws Exception {
		try {
			ChromeMCP_startRemoteDriver();
			info("Entered into start Shift function");
			String startShiftPage = "//div[@id='m1ShiftButtonTemplate']//span[text()='Start']";
			Webdriver_waitToClick(startShiftPage);
			// Thread.sleep(60000);
			// WebElement startShiftButton =
			// driver.findElement(By.xpath("//div[@id='m1ShiftButtonTemplate']//span[text()='Start']"));

			WebElement startShiftButton = driver
					.findElement(By.xpath("//div[@id='m1ShiftButtonTemplate']//span[text()='Start']"));
			info("Start Shift Button is present in the page");
            Thread.sleep(3000);
			startShiftButton.click();
			info("Start Shift Button is clicked");

			
			 * (new WebDriverWait(driver,
			 * 60)).until(ExpectedConditions.presenceOfElementLocated(By.xpath(
			 * "//div[@id='allHeaders']//span[text()='Shift']"))); WebElement
			 * startShiftButton = (new WebDriverWait(driver,
			 * 20)).until(ExpectedConditions.presenceOfElementLocated(By.xpath(
			 * "//div[@id='m1ShiftButtonTemplate']//span[text()='Start']")));
			 * info("Start Shift Button is present in the page"); (new WebDriverWait(driver,
			 * 100)).until(ExpectedConditions.visibilityOf(startShiftButton));
			 * info("Start Shift Button is visible in the page"); Thread.sleep(1000); (new
			 * WebDriverWait(driver,
			 * 100)).until(ExpectedConditions.elementToBeClickable(startShiftButton));
			 * startShiftButton.click(); info("Start Shift Button is clicked");
			 
		} catch (TimeoutException e) {
			fail(e.getMessage());
			InfoDescription = e.getMessage();
			logComments(InfoDescription, CONST_FAILED);
			return "N";
		}
		Thread.sleep(3500);
		return "N";
	}

	public String HybridMCP_waitForTaskDispatch(String totalTaskCount, String MaxTimeToWaitInSeconds) throws Exception {
		try {
			int task_count = Integer.parseInt(totalTaskCount); // Fetch from Test-Data
			int waitTime = Integer.parseInt(MaxTimeToWaitInSeconds);

			Thread.sleep(5000);

			WebElement openTab = driver.findElement(By.id("openTab-label"));
			info("Tab is visible in the page");
			openTab.click();
			info("Waiting for all tasks to get loaded");
			String xpath1 = "//ul[@id='tasklistview']";
			Webdriver_waitToVisible(xpath1);
			Thread.sleep(180000);
			WebElement allTasksDispatched = driver
					.findElement(By.xpath("//ul[@id='tasklistview']/li[" + task_count + "]"));
			info("All " + task_count + " tasks are loaded.");

			
			 * WebElement openTab = (new WebDriverWait(driver, 90))
			 * .until(ExpectedConditions.presenceOfElementLocated(By.xpath(
			 * "//a[@id='openTab-label']"))); (new WebDriverWait(driver, 100))
			 * .until(ExpectedConditions.visibilityOf(openTab));
			 * info("Tab is visible in the page"); Thread.sleep(1000); openTab.click();
			 * 
			 * //Waiting for Nth Task to dispatched (new WebDriverWait(driver, waitTime))
			 * .until(ExpectedConditions.presenceOfElementLocated(By.xpath(
			 * "//ul[@id='tasklistview']/li["+task_count+"]"))); //Wait until all tasks are
			 * added to the screen info("All "+task_count+" tasks are loaded."); //To Notify
			 * Thread.sleep(5000); //Stale Exception: 5 Sec wait
			  } catch (Exception e) {
			fail(e.getMessage());
			InfoDescription = e.getMessage();
			logComments(InfoDescription, CONST_FAILED);
			return "N";
		}
		return "N";
	}

	public String HybridMCP_waitForAllTaskDispatch(String totalTaskCount, String MaxTimeToWaitInSeconds)
			throws Exception {
		try {
			int task_count = Integer.parseInt(totalTaskCount); // Fetch from Test-Data
			int waitTime = Integer.parseInt(MaxTimeToWaitInSeconds);

			Thread.sleep(10000);
			WebElement openTab = driver.findElement(By.id("openTab-label"));
			info("Tab is visible in the page");
			openTab.click();
			info("Waiting for all tasks to get loaded");
			Thread.sleep(180000);
			WebElement allTasksDispatched = driver
					.findElement(By.xpath("//ul[@id='tasklistview']/li[" + task_count + "]"));
			info("All " + task_count + " tasks are loaded.");

			
			 * WebElement openTab = (new WebDriverWait(driver, 90))
			 * .until(ExpectedConditions.presenceOfElementLocated(By.xpath(
			 * "//a[@id='openTab-label']"))); (new WebDriverWait(driver, 100))
			 * .until(ExpectedConditions.visibilityOf(openTab));
			 * info("Tab is visible in the page"); Thread.sleep(1000); openTab.click();
			 * 
			 * //Waiting for Nth Task to dispatched (new WebDriverWait(driver, waitTime))
			 * .until(ExpectedConditions.presenceOfElementLocated(By.xpath(
			 * "//ul[@id='tasklistview']/li["+task_count+"]"))); //Wait until all tasks are
			 * added to the screen info("All "+task_count+" tasks are loaded."); //To Notify
			 * Thread.sleep(5000); //Stale Exception: 5 Sec wait
			  } catch (Exception e) {
			fail(e.getMessage());
			InfoDescription = e.getMessage();
			logComments(InfoDescription, CONST_FAILED);
			return "N";
		}
		return "N";
	}

	public String HybridMCP_gotoTaskHome(String initialWaitTimeMilliSeconds) throws Exception {
		try {
			int waitTime = Integer.parseInt(initialWaitTimeMilliSeconds); // Fetch from Test-Data
			info("Waiting for " + initialWaitTimeMilliSeconds + " Seconds");
			Thread.sleep(waitTime);

			
			 * WebElement menuButton = (new WebDriverWait(driver,
			 * 100)).until(ExpectedConditions.presenceOfElementLocated(By.xpath(
			 * "//a[@id='pageMenuButton']"))); info("Menu Button is present in the page");
			 * (new WebDriverWait(driver, 100))
			 * .until(ExpectedConditions.visibilityOf(menuButton));
			 * info("Menu Button is visible in the page"); Thread.sleep(1000); (new
			 * WebDriverWait(driver, 100))
			 * .until(ExpectedConditions.elementToBeClickable(menuButton));
			 * Thread.sleep(1000); menuButton.click(); info("Page Menu button is Clicked");
			 Thread.sleep(1500);
			info("Clicking the Page Menu button");
			driver.findElement(By.id("pageMenuButton")).click();
			Thread.sleep(2000);
			driver.findElement(By.xpath("//li[@class='ui-first-child']/following-sibling::li[3]")).click();

			Thread.sleep(6000);
			info("Home Menu button is clicked");
		} catch (Exception e) {
			fail(e.getMessage());
			InfoDescription = e.getMessage();
			logComments(InfoDescription, CONST_FAILED);
			return "N";
		}
		return "N";
	}
	public String HybridMCP_gotoTaskHome(String initialWaitTimeMilliSeconds) throws Exception {
		try {
			int waitTime = Integer.parseInt(initialWaitTimeMilliSeconds); // Fetch from Test-Data
			info("Waiting for " + initialWaitTimeMilliSeconds + " Seconds");
			Thread.sleep(waitTime);

			
			  WebElement menuButton = (new WebDriverWait(driver,
			  100)).until(ExpectedConditions.presenceOfElementLocated(By.xpath(
			  "//a[@id='pageMenuButton']"))); info("Menu Button is present in the page");
			  (new WebDriverWait(driver, 100))
			  .until(ExpectedConditions.visibilityOf(menuButton));
			  info("Menu Button is visible in the page"); Thread.sleep(1000); (new
			  WebDriverWait(driver, 100))
			  .until(ExpectedConditions.elementToBeClickable(menuButton));
			 Thread.sleep(1000); menuButton.click(); info("Page Menu button is Clicked");
			 Thread.sleep(2500);
			info("Clicking the Page Menu button");
			driver.findElement(By.id("pageMenuButton")).click();
			Thread.sleep(2000);
			driver.findElement(By.xpath("//li[@class='ui-first-child']/following-sibling::li[2]")).click();

			Thread.sleep(6000);
			info("Home Menu button is clicked");
		} catch (Exception e) {
			fail(e.getMessage());
			InfoDescription = e.getMessage();
			logComments(InfoDescription, CONST_FAILED);
			return "N";
		}
		return "N";
	}
	public String HybridMCP_startBreak(String break_task_id, String MaxTimeToWaitInMilliSeconds) throws Exception {
		try {
			String headerText = clickByAssignmentID(break_task_id);
			info("Break Task is Opened. The Header-Text is: " + headerText);
			WebElement startButton = driver.findElement(By.xpath("//div/a[@role='button']//span[text()='Start']"));
			
			 * WebElement startButton = (new WebDriverWait(driver, 60))
			 * .until(ExpectedConditions.presenceOfElementLocated(By.xpath(
			 * "//div/a[@role='button']//span[text()='Start']")));
			 
			info("Clicking the START button");
			startButton.click();
			info("START button is Clicked");
			Thread.sleep(3500);

		} catch (Exception e) {
			fail(e.getMessage());
			InfoDescription = e.getMessage();
			logComments(InfoDescription, CONST_FAILED);
			return "N";
		}
		return "N";
	}

	public String HybridMCP_completeBreak() throws Exception {
		try {
			info("Clicking the COMPLETE button");
			driver.findElement(By.xpath("//div/a[@role='button']//span[text()='Complete']")).click();
			info("COMPLETE button is Clicked");
		} catch (Exception e) {
			fail(e.getMessage());
			InfoDescription = e.getMessage();
			logComments(InfoDescription, CONST_FAILED);
			return "N";
		}
		return "N";
	}

	public String HybridMCP_startNonProductiveTask(String npt_task_id, String MaxTimeToWaitInMilliSeconds)
			throws Exception {
		try {
			String headerText = clickByAssignmentID(npt_task_id);
			WebElement enrouteButton = driver.findElement(By.xpath("//div/a[@role='button']//span[text()='Enroute']"));

			
			 * WebElement enrouteButton = (new WebDriverWait(driver, 60))
			 * .until(ExpectedConditions.presenceOfElementLocated(By.xpath(
			 * "//div/a[@role='button']//span[text()='Enroute']")));
			  Thread.sleep(2500);
			enrouteButton.click();
			Thread.sleep(4000);
			driver.findElement(By.xpath("//div/a[@role='button']//span[text()='Onsite']")).click();
			Thread.sleep(3000);
		} catch (Exception e) {
			fail(e.getMessage());
			InfoDescription = e.getMessage();
			logComments(InfoDescription, CONST_FAILED);
			return "N";
		}
		return "N";
	}

	public String HybridMCP_completeNonProductiveTask() throws Exception {
		try {

			Thread.sleep(5000);
			WebElement completeButton = driver
					.findElement(By.xpath("//div/a[@role='button']//span[text()='Complete']"));

			
			 * WebElement completeButton = (new WebDriverWait(driver, 60))
			 * .until(ExpectedConditions.presenceOfElementLocated(By.xpath(
			 * "//div/a[@role='button']//span[text()='Complete']")));
			 
			completeButton.click();
		} catch (Exception e) {
			fail(e.getMessage());
			InfoDescription = e.getMessage();
			logComments(InfoDescription, CONST_FAILED);
			return "N";
		}
		return "N";
	}

	public String HybridMCP_startPOU(String pou_task_id, String MaxTimeToWaitInMilliSeconds) throws Exception {
		try {
			String headerText = clickByAssignmentID(pou_task_id);

			Thread.sleep(5000);
			WebElement enrouteButton = driver.findElement(By.xpath("//div/a[@role='button']//span[text()='Enroute']"));

			
			 * WebElement enrouteButton = (new WebDriverWait(driver, 60))
			 * .until(ExpectedConditions.presenceOfElementLocated(By.xpath(
			 * "//div/a[@role='button']//span[text()='Enroute']")));
			 
			Thread.sleep(2500);
			enrouteButton.click();
			Thread.sleep(4000);
			driver.findElement(By.xpath("//div/a[@role='button']//span[text()='Onsite']")).click();
			Thread.sleep(3000);
		} catch (Exception e) {
			fail(e.getMessage());
			InfoDescription = e.getMessage();
			logComments(InfoDescription, CONST_FAILED);
			return "N";
		}
		return "N";
	}

	public String HybridMCP_completePOU() throws Exception {
		try {

			Thread.sleep(5000);

			WebElement completeButton = driver
					.findElement(By.xpath("//div/a[@role='button']//span[text()='Complete']"));

			
			 * WebElement completeButton = (new WebDriverWait(driver, 60))
			 * .until(ExpectedConditions.presenceOfElementLocated(By.xpath(
			 * "//div/a[@role='button']//span[text()='Complete']")));
			 
			completeButton.click();
		} catch (Exception e) {
			fail(e.getMessage());
			InfoDescription = e.getMessage();
			logComments(InfoDescription, CONST_FAILED);
			return "N";
		}
		return "N";
	}

	// Add Task: M1-GetAssignmentIdForTaskId

	public String HybridMCP_startM1Activity(String activity_task_id, String MaxTimeToWaitInMilliSeconds)
			throws Exception {
		try {
			// String headerText = clickByAssignmentID(activity_task_id);
			// info("Header Text: "+headerText);
			Thread.sleep(5000);
			driver.findElement(By.xpath("//*[contains(text(),'AT_ACTIVITY TYPE1')]")).click();

			Thread.sleep(5000);
			WebElement enrouteButton = driver
					.findElement(By.xpath("//*[contains(text(),'En Route')]"));
			
			 * WebElement enrouteButton = (new WebDriverWait(driver, 60))
			 * .until(ExpectedConditions.presenceOfElementLocated(By.
			 * xpath("//div/a[@role='button']//span[text()='En Route']")));
			 
			enrouteButton.click();
			Thread.sleep(6000);
			
			
			
			
			
			WebElement startButton = driver.findElement(By.xpath("//span[contains(text(),'Start')]"));
			
			 * WebElement startButton = (new WebDriverWait(driver, 60))
			 * .until(ExpectedConditions.presenceOfElementLocated(By.xpath(
			 * "//div/a[@role='button']//span[text()='Start']")));
			 

			startButton.click();

			Thread.sleep(7000);
			
			 * WebElement completionTab = (new WebDriverWait(driver, 60))
			 * .until(ExpectedConditions.presenceOfElementLocated(By.xpath(
			 * "//span[@id='m1CommonCmpl-lbl']"))); Thread.sleep(2000);
			 * 
			 * if(driver.findElements(By.
			 * xpath("//span[@id='m1CommonCmpl-lbl']/../span[contains(text(),'click to expand contents')]"
			 * )).size() != 0){ completionTab.click(); }
			 

			Thread.sleep(2500);
			
			 * WebElement dropDownSelect =
			 * driver.findElement(By.id("m1CCCustomerContactType")); Select mySelect= new
			 * Select(dropDownSelect); mySelect.selectByValue("WEB");
			 * 
			 * Thread.sleep(1000);
			 * 
			 * driver.findElement(By.xpath("//textarea[@id='m1CCCustomerContactComments']"))
			 * .sendKeys("Contact comments of this Activity."); Thread.sleep(1000);
			 * driver.findElement(By.xpath("//textarea[@id='m1CCToDoMessage']")).
			 * sendKeys("Review is not required for this Sample Activity.");
			 * Thread.sleep(1000);
			 * driver.findElement(By.xpath("//textarea[@id='m1CCComments']")).
			 * sendKeys("Sample Comment for this Activity.");
			 * 
			 * Thread.sleep(1500);
			 
		} catch (Exception e) {
			fail(e.getMessage());
			InfoDescription = e.getMessage();
			logComments(InfoDescription, CONST_FAILED);
			return "N";
		}
		return "N";
	}
	
	//Commented for making changed to add attachment.
	public String HybridMCP_startM1Activity(String activity_task_id, String MaxTimeToWaitInMilliSeconds)
			throws Exception {
		try {
			// String headerText = clickByAssignmentID(activity_task_id);
			// info("Header Text: "+headerText);
			Thread.sleep(5000);
			driver.findElement(By.xpath("//android.view.View[contains(@content-desc ,'AT_ACTIVITY TYPE1')]")).click();

			Thread.sleep(5000);
			WebElement enrouteButton = driver
					.findElement(By.xpath("//android.widget.Button[@content-desc ='En Route']"));
			
			 * WebElement enrouteButton = (new WebDriverWait(driver, 60))
			 * .until(ExpectedConditions.presenceOfElementLocated(By.
			 * xpath("//div/a[@role='button']//span[text()='En Route']")));
			 
			enrouteButton.click();
			Thread.sleep(5000);
			WebElement startButton = driver.findElement(By.xpath("//android.widget.Button[@content-desc ='Start']"));
			
			 * WebElement startButton = (new WebDriverWait(driver, 60))
			 * .until(ExpectedConditions.presenceOfElementLocated(By.xpath(
			 * "//div/a[@role='button']//span[text()='Start']")));
			 

			startButton.click();

			Thread.sleep(7000);
			
			 * WebElement completionTab = (new WebDriverWait(driver, 60))
			 * .until(ExpectedConditions.presenceOfElementLocated(By.xpath(
			 * "//span[@id='m1CommonCmpl-lbl']"))); Thread.sleep(2000);
			 * 
			 * if(driver.findElements(By.
			 * xpath("//span[@id='m1CommonCmpl-lbl']/../span[contains(text(),'click to expand contents')]"
			 * )).size() != 0){ completionTab.click(); }
			 

			Thread.sleep(2500);
			
			 * WebElement dropDownSelect =
			 * driver.findElement(By.id("m1CCCustomerContactType")); Select mySelect= new
			 * Select(dropDownSelect); mySelect.selectByValue("WEB");
			 * 
			 * Thread.sleep(1000);
			 * 
			 * driver.findElement(By.xpath("//textarea[@id='m1CCCustomerContactComments']"))
			 * .sendKeys("Contact comments of this Activity."); Thread.sleep(1000);
			 * driver.findElement(By.xpath("//textarea[@id='m1CCToDoMessage']")).
			 * sendKeys("Review is not required for this Sample Activity.");
			 * Thread.sleep(1000);
			 * driver.findElement(By.xpath("//textarea[@id='m1CCComments']")).
			 * sendKeys("Sample Comment for this Activity.");
			 * 
			 * Thread.sleep(1500);
			 
		} catch (Exception e) {
			fail(e.getMessage());
			InfoDescription = e.getMessage();
			logComments(InfoDescription, CONST_FAILED);
			return "N";
		}
		return "N";
	}

	public int HybridMCP_listOfActivities() throws Exception {

		int numberOfTasks = 0;
		try {
			String activities = "//ul[@id='tasklistview']//li[@class='ui-first-child ui-mini']";
			Webdriver_waitToVisible(activities);
			List<WebElement> listOfActivities = driver
					.findElements(By.xpath("//ul[@id='tasklistview']//li[@class='ui-first-child ui-mini']"));
			numberOfTasks = listOfActivities.size();

		} catch (Exception e) {
			fail(e.getMessage());
			InfoDescription = e.getMessage();
			logComments(InfoDescription, CONST_FAILED);

		}
		return numberOfTasks;

	}
	
	//Selects work status in Hybrid MCP Browser
	public void HybridBrowser_selectWorkStatus(String status) throws Exception {
		try {
			// Selecting KeepWithCrew
			driver.findElement(By.xpath("//div[@id='m2PkActPickupStatus-button']")).click();
			String wStatus = "//div[@id='m2PkActPickupStatus-button']//option[text()='" + status + "']";
			Webdriver_waitToClick(wStatus);
			driver.findElement(By.xpath(wStatus)).click();

		} catch (Exception e) {
			fail(e.getMessage());
			InfoDescription = e.getMessage();
			logComments(InfoDescription, CONST_FAILED);
		}
	}
	//Selects work status in Hybrid MCP Mobile
	public void HybridMCPM2_selectWorkStatus(String status) throws Exception {
		try {
			// Selecting KeepWithCrew
			driver.findElement(MobileBy.id("m1PkActPickupStatus-button")).click();
			String wStatus = "//div[@id='m1PkActPickupStatus-button']//option[text()='" + status + "']";
			Webdriver_waitToClick(wStatus);
			driver.findElement(By.xpath(wStatus)).click();
			Thread.sleep(3000);
			String workStatusdropdown = "//div[@id='m2PkActPickupStatus-button']//select";			
			driver.findElement(By.xpath(workStatusdropdown)).click();
			Thread.sleep(1000);
			String workStatus = "//*[text()='" + status + "']";
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();",
					driver.findElement(By.xpath(workStatus)));
			Webdriver_waitToClick(workStatus);
			driver.findElement(By.xpath(workStatus)).click();

		} catch (Exception e) {
			fail(e.getMessage());
			InfoDescription = e.getMessage();
			logComments(InfoDescription, CONST_FAILED);
		}
	}
	
	//Selects work status in Hybrid MCP Mobile M2
		public void HybridMCP_selectWorkStatus(String status) throws Exception {
			try {
				// Selecting KeepWithCrew
				driver.findElement(MobileBy.id("m1PkActPickupStatus-button")).click();
				String wStatus = "//div[@id='m1PkActPickupStatus-button']//option[text()='" + status + "']";
				Webdriver_waitToClick(wStatus);
				driver.findElement(By.xpath(wStatus)).click();

			} catch (Exception e) {
				fail(e.getMessage());
				InfoDescription = e.getMessage();
				logComments(InfoDescription, CONST_FAILED);
			}
		}

	public void HybridMCP_selectDeclineStatus(String status) throws Exception {
		try {
			// Selecting KeepWithCrew
			driver.findElement(MobileBy.id("m1RDBoStatusReason-fld-button")).click();
			String wStatus = "//div[@id='m1RDBoStatusReason-fld-button']//option[text()='" + status + "']";
			Webdriver_waitToClick(wStatus);
			driver.findElement(By.xpath(wStatus)).click();

		} catch (Exception e) {
			fail(e.getMessage());
			InfoDescription = e.getMessage();
			logComments(InfoDescription, CONST_FAILED);
		}
	}

	public void HybridMCP_processAction() throws Exception {
		try {
			// Clicking on Process Action Button
			String processActionButton = "//a[@id='processActionButton']";
			Webdriver_waitToClick(processActionButton);
			driver.findElement(By.xpath("//a[@id='processActionButton']")).click();

		} catch (Exception e) {
			fail(e.getMessage());
			InfoDescription = e.getMessage();
			logComments(InfoDescription, CONST_FAILED);
		}
	}

	public void HybridMCP_scrollAndSelectDropdown(String activityType) throws Exception {
		try {
			// clicking on activity dropdown
			String activityDropdown = "//div[@id='m1SPkTargetTaskType-button']";
			Webdriver_waitToClick(activityDropdown);
			driver.findElement(By.xpath(activityDropdown)).click();

			// Scrolling and selecting the required dropdown value
			// String activityName =
			// "//select[@id='tsklstSPkTargetTaskType']//option[@value='"+activityType+"']";
			String activityName = "//*[text()='" + activityType + "']";
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();",
					driver.findElement(By.xpath(activityName)));
			driver.findElement(By.xpath(activityName)).click();

		} catch (Exception e) {
			fail(e.getMessage());
			InfoDescription = e.getMessage();
			logComments(InfoDescription, CONST_FAILED);
		}
	}

	public void HybridMCP_selectDropdown(String value) throws Exception {
		try {
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();",
					driver.findElement(By.xpath(value)));
			driver.findElement(By.xpath(value)).click();

		} catch (Exception e) {
			fail(e.getMessage());
			InfoDescription = e.getMessage();
			logComments(InfoDescription, CONST_FAILED);
		}
	}

	// Click on En-Route Button
	public void HybridMCP_clickOnEnRoute() throws Exception {
		try {
			// clicking on activity dropdown
			String enRouteButton = "//span[text()='En Route']";
			Webdriver_waitToClick(enRouteButton);
			driver.findElement(By.xpath(enRouteButton)).click();

		} catch (Exception e) {
			fail(e.getMessage());
			InfoDescription = e.getMessage();
			logComments(InfoDescription, CONST_FAILED);
		}
	}
	

	// Add attachment in M1 activity flow
		public void HybridMCP_addAttachment() throws Exception {
			try {
				driver.findElement(By.xpath("//span[contains(text(),'AT_ACTIVITY TYPE1, ')]")).click();
				WebDriverWait wait = new WebDriverWait(driver, 240);
				wait.until(ExpectedConditions.elementToBeClickable(By.id("pageMenuButton")));
				driver.findElement(MobileBy.id("pageMenuButton")).click();
				//Click on Attachments button
				String attachments = "//div[@id='popupMenu']//span[text()='Attachments']";
				Webdriver_waitToClick(attachments);
				driver.findElement(By.xpath(attachments)).click();
				String galleryButton = "//a[@id='browsePicture']";
				Webdriver_waitToClick(galleryButton);
				driver.findElement(By.xpath(galleryButton)).click();
				Thread.sleep(2000);
				driver.findElement(By.name("Gallery")).click();
				Thread.sleep(2000);
				driver.findElement(By.xpath("//*[@class='com.sec.samsung.gallery.glview.composeView.PositionControllerBase$ThumbObject' and @index=4]")).click();
				Thread.sleep(2000);
				//String image4="//com.sec.android.gallery3d[@index='4']";
				Webdriver_waitToClick(image4);
				driver.findElement(By.xpath(image4)).click();
				Thread.sleep(20000);
			} catch (Exception e) {
				fail(e.getMessage());
				InfoDescription = e.getMessage();
				logComments(InfoDescription, CONST_FAILED);
			}
		}

	// Click on Suspend Button
	public void HybridMCP_clickOnSuspend() throws Exception {
		try {
			// clicking on activity dropdown
			String suspendButton = "//span[text()='Suspend']";
			Webdriver_waitToClick(suspendButton);
			driver.findElement(By.xpath(suspendButton)).click();

		} catch (Exception e) {
			fail(e.getMessage());
			InfoDescription = e.getMessage();
			logComments(InfoDescription, CONST_FAILED);
		}
	}

	// Click on Decline Button
	public void HybridMCP_declineFlow(String Status, String keepWithCrewYesORNo, String description) throws Exception {
		try {
			String enRouteButton = "//span[text()='Decline']";
			Webdriver_waitToClick(enRouteButton);
			driver.findElement(By.xpath(enRouteButton)).click();
			HybridMCP_selectDeclineStatus(Status);
			driver.findElement(By.xpath("//select[@id='m1RDSameCrew']/option[text()='" + keepWithCrewYesORNo + "']"))
					.click();
			driver.findElement(By.xpath("//textarea[@id='m1RDDeclineComments']")).sendKeys(description);
			HybridMCP_processAction();
			Webdriver_waitToClick("//a[@id='pageMenuButton']");
		} catch (Exception e) {
			fail(e.getMessage());
			InfoDescription = e.getMessage();
			logComments(InfoDescription, CONST_FAILED);
		}
	}

	// Click on Decline Button
	public void HybridMCP_postponeFlow(String keepWithCrewYesOrNo) throws Exception {
		try {
			String postponeButton = "//span[text()='Postpone']";
			Webdriver_waitToClick(postponeButton);
			driver.findElement(By.xpath(postponeButton)).click();
			// HybridMCP_selectDeclineStatus(Status);
			Webdriver_waitToVisible("//select[@id='m1PDSameCrew']");
			info("Enter No if 'Yes Value is required in the Edit Test data for the Keep With Crew field'");
			driver.findElement(By.xpath("//select[@id='m1PDSameCrew']/option[text()='" + keepWithCrewYesOrNo + "']"))
					.click();
			HybridMCP_processAction();
			Webdriver_waitToClick("//a[@id='pageMenuButton']");
		} catch (Exception e) {
			fail(e.getMessage());
			InfoDescription = e.getMessage();
			logComments(InfoDescription, CONST_FAILED);
		}
	}

	// En-Route and complete Flow
	public void HybridMCP_enRouteStartAndCompleteFlow() throws Exception {
		try {
			HybridMCP_clickOnEnRoute();
			HybridMCP_clickStartAtWorkSite();
			HybridMCP_clickCompleteButton();
			Webdriver_waitToClick("//a[@id='pageMenuButton']");
		} catch (Exception e) {
			fail(e.getMessage());
			InfoDescription = e.getMessage();
			logComments(InfoDescription, CONST_FAILED);
		}
	}

	// En-Route and Suspend Flow
	public void HybridMCP_enRouteStartAndSuspendFlow(String keepWithCrewYesOrNo) throws Exception {
		try {
			HybridMCP_clickOnEnRoute();
			HybridMCP_clickStartAtWorkSite();
			HybridMCP_clickOnSuspend();
			Webdriver_waitToVisible("//select[@id='m1SDSameCrew']");
			info("Enter No if 'Yes Value is required in the Edit Test data for the Keep With Crew field'");
			driver.findElement(By.xpath("//select[@id='m1SDSameCrew']//option[text()='" + keepWithCrewYesOrNo + "']"))
					.click();
			String timeRemaining = "//span[@id='m1SDEstimatedTimeLeft']/ancestor::a//span[text()='Time Remaining']";
			driver.findElement(By.xpath(timeRemaining)).click();
			// Enter Hours
			driver.findElement(By.xpath("//div[@id='durationPicker-popup']//div[@class='ui-block-a ui-mini']")).click();
			driver.findElement(By.xpath("//div[@id='durationPicker-popup']//div[@class='ui-block-a ui-mini']/input"))
					.click();
			driver.findElement(By.xpath("//div[@id='durationPicker-popup']//div[@class='ui-block-a ui-mini']//input"))
					.sendKeys("01");

			// Enter Minutes
			driver.findElement(By.xpath("//div[@id='durationPicker-popup']//div[@class='ui-block-b ui-mini']")).click();
			driver.findElement(By.xpath("//div[@id='durationPicker-popup']//div[@class='ui-block-b ui-mini']/input"))
					.click();
			driver.findElement(By.xpath("//div[@id='durationPicker-popup']//div[@class='ui-block-a ui-mini']//input"))
					.sendKeys("02");
			// Enter Seconds
			driver.findElement(By.xpath("//div[@id='durationPicker-popup']//div[@class='ui-block-c ui-mini']")).click();
			driver.findElement(By.xpath("//div[@id='durationPicker-popup']//div[@class='ui-block-c ui-mini']/input"))
					.click();
			driver.findElement(By.xpath("//div[@id='durationPicker-popup']//div[@class='ui-block-a ui-mini']//input"))
					.sendKeys("02");
			driver.findElement(By.xpath("//div[@id='durationPicker-popup']//a[2]")).click();
			HybridMCP_processAction();
			Webdriver_waitToClick("//a[@id='pageMenuButton']");
		} catch (Exception e) {
			fail(e.getMessage());
			InfoDescription = e.getMessage();
			logComments(InfoDescription, CONST_FAILED);
		}
	}

	// En-Route and Decline Flow
	public void HybridMCP_enRouteStartAndDeclineFlow(String statusReason, String keepWithCrewYesOrNo,
			String description) throws Exception {
		try {
			HybridMCP_clickOnEnRoute();
			HybridMCP_clickStartAtWorkSite();
			Webdriver_waitToClick("//select[@id='popActionDropdown']");
			driver.findElement(By.xpath("//select[@id='popActionDropdown']")).click();
			HybridMCP_selectDropdown("//select[@id='popActionDropdown']/option[text()='Decline']");
			HybridMCP_selectDeclineStatus(statusReason);
			// Keep with Crew Yes or No
			Webdriver_waitToVisible("//select[@id='m1RDSameCrew']");
			info("Enter No if 'Yes Value is required in the Edit Test data for the Keep With Crew field'");
			driver.findElement(By.xpath("//select[@id='m1RDSameCrew']/option[text()='" + keepWithCrewYesOrNo + "']"))
					.click();
			driver.findElement(By.xpath("//textarea[@id='m1RDDeclineComments']")).sendKeys(description);
			HybridMCP_processAction();
			Webdriver_waitToClick("//a[@id='pageMenuButton']");
		} catch (Exception e) {
			fail(e.getMessage());
			InfoDescription = e.getMessage();
			logComments(InfoDescription, CONST_FAILED);
		}
	}

	// Click on StartButton
	public void HybridMCP_clickStartAtWorkSite() throws Exception {
		try {
			// clicking on activity dropdown
			String startButton = "//span[text()='Start']";
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();",
					driver.findElement(By.xpath(startButton)));
			Webdriver_waitToClick(startButton);
			driver.findElement(By.xpath(startButton)).click();

		} catch (Exception e) {
			fail(e.getMessage());
			InfoDescription = e.getMessage();
			logComments(InfoDescription, CONST_FAILED);
		}
	}

	// Click on StartButton
	public void HybridMCP_clickCompleteButton() throws Exception {
		try {
			// clicking on activity dropdown
			String completeButton = "//span[text()='Complete']";
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();",
					driver.findElement(By.xpath(completeButton)));
			Webdriver_waitToClick(completeButton);
			driver.findElement(By.xpath(completeButton)).click();

		} catch (Exception e) {
			fail(e.getMessage());
			InfoDescription = e.getMessage();
			logComments(InfoDescription, CONST_FAILED);
		}
	}
	
	//Completes Electric Install Meter
		public void HybridBrowser_completeElectricInstallMeterActivity() throws Exception {
			try {
				
				String badgeNumber = "//input[@id='m2NMBadgeNum']";
				Webdriver_waitToClick(badgeNumber);
				driver.findElement(By.xpath(badgeNumber)).sendKeys("43534");
				driver.findElement(By.xpath("//a[@id='m2NMBtnVerify']")).click();
				Thread.sleep(1000);
				driver.findElement(By.xpath("//a[text()='Overridden']")).click();
				Thread.sleep(1000);
				driver.findElement(By.xpath("//div[@id='m2NMMMeterConfigurationType-button']//select")).click();
				String configurationType = "//div[@id='m2NMMMeterConfigurationType-button']//option[2]";
				((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();",
						driver.findElement(By.xpath(configurationType)));
				//Webdriver_waitToClick(statusLeft);
				driver.findElement(By.xpath(configurationType)).click();
				// Entering kw details
				String kw ="//div[@id='m2NMDivReadings']//span[text()='KW']";
				Webdriver_waitToClick(kw);
				((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();",
						driver.findElement(By.xpath(kw)));
				driver.findElement(By.xpath(kw)).click();
				String kwReading ="//input[@id='m2NMRRReading']";
				Webdriver_waitToClick(kwReading);
				driver.findElement(By.xpath(kwReading)).sendKeys("123");
				HybridMCP_processAction();
				
				//Entering kwh Reading:
				String kwh ="//div[@id='m2NMDivReadings']//span[text()='KWH']";
				Webdriver_waitToClick(kwh);
				((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();",
						driver.findElement(By.xpath(kwh)));
				driver.findElement(By.xpath(kwh)).click();
				String kwhReading ="//input[@id='m2NMRRReading']";
				Webdriver_waitToClick(kwhReading);
				driver.findElement(By.xpath(kwhReading)).sendKeys("123");
				HybridMCP_processAction();
				
				//Status Left selection
				driver.findElement(By.xpath("//div[@id='m2NMDeviceStatusLeft-button']//select")).click();
				String statusLeft = "//div[@id='m2NMDeviceStatusLeft-button']//option[2]";
				((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();",
						driver.findElement(By.xpath(statusLeft)));
				Webdriver_waitToClick(statusLeft);
				driver.findElement(By.xpath(statusLeft)).click();
				
				String completeButton = "//span[text()='Complete']";
				
				((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();",
						driver.findElement(By.xpath(completeButton)));
				Webdriver_waitToClick(completeButton);
				driver.findElement(By.xpath(completeButton)).click();

			} catch (Exception e) {
				fail(e.getMessage());
				InfoDescription = e.getMessage();
				logComments(InfoDescription, CONST_FAILED);
			}
		}
		
		//Completes Electric Install Meter
		public void HybridBrowser_completeRemoveMeterActivity() throws Exception {
					try {
						try {
							String modifiedDropdown = "//div[@class='ui-block-b']//span[text()='Modified']";
							Webdriver_waitToClick(modifiedDropdown);
							driver.findElement(By.xpath(modifiedDropdown)).click();
						}catch(Exception e) {
							
						}					
						
						String badgeNumber = "//input[@id='m2EMMBadgeNumber']";
						Webdriver_waitToClick(badgeNumber);
						driver.findElement(By.xpath(badgeNumber)).sendKeys("43534");
						Thread.sleep(1000);
						driver.findElement(By.xpath("//div[@id='m2EMMMeterConfigurationType-button']//select")).click();
						String configurationType = "//div[@id='m2EMMMeterConfigurationType-button']//option[6]";
						((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();",
								driver.findElement(By.xpath(configurationType)));
						Webdriver_waitToClick(configurationType);
						driver.findElement(By.xpath(configurationType)).click();
						
						//Status Found selection
						driver.findElement(By.xpath("//div[@id='m2EMDDeviceStatusFound-button']//select")).click();
						String statusFound = "//div[@id='m2EMDDeviceStatusFound-button']//option[2]";
						((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();",
								driver.findElement(By.xpath(statusFound)));
						Webdriver_waitToClick(statusFound);
						driver.findElement(By.xpath(statusFound)).click();
						
						//Status Left selection
						driver.findElement(By.xpath("//div[@id='m2EMDDeviceStatusLeft-button']//select")).click();
						String statusLeft = "//div[@id='m2EMDDeviceStatusLeft-button']//option[2]";
						((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();",
								driver.findElement(By.xpath(statusLeft)));
						Webdriver_waitToClick(statusLeft);
						driver.findElement(By.xpath(statusLeft)).click();
						
						//Entering kwh Reading:
						String kwh ="//div[@id='m2EMDivReadings']//span[text()='KWH']";
						Webdriver_waitToClick(kwh);
						((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();",
								driver.findElement(By.xpath(kwh)));
						driver.findElement(By.xpath(kwh)).click();
						String kwhReading ="//input[@id='m2RRReading']";
						Webdriver_waitToClick(kwhReading);
						driver.findElement(By.xpath(kwhReading)).sendKeys("123");
						HybridMCP_processAction();	
						
						String completeButton = "//span[text()='Complete']";
						
						((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();",
								driver.findElement(By.xpath(completeButton)));
						Webdriver_waitToClick(completeButton);
						driver.findElement(By.xpath(completeButton)).click();
				   } catch (Exception e) {
						fail(e.getMessage());
						InfoDescription = e.getMessage();
						logComments(InfoDescription, CONST_FAILED);
					}
				}
		
		//Completes Meter Read Activity
				public void HybridBrowser_completeMeterReadActivity() throws Exception {
							try {
								
								String modifiedDropdown = "//div[@class='ui-block-b']//span[text()='Modified']";
								Webdriver_waitToClick(modifiedDropdown);
								driver.findElement(By.xpath(modifiedDropdown)).click();
								
								String badgeNumber = "//input[@id='m2EMMBadgeNumber']";
								Webdriver_waitToClick(badgeNumber);
								driver.findElement(By.xpath(badgeNumber)).sendKeys("43534");
								Thread.sleep(1000);
								driver.findElement(By.xpath("//div[@id='m2EMMMeterConfigurationType-button']//select")).click();
								String configurationType = "//div[@id='m2EMMMeterConfigurationType-button']//option[6]";
								((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();",
										driver.findElement(By.xpath(configurationType)));
								Webdriver_waitToClick(configurationType);
								driver.findElement(By.xpath(configurationType)).click();
								
								//Status Found selection
								driver.findElement(By.xpath("//div[@id='m2EMDDeviceStatusFound-button']//select")).click();
								String statusFound = "//div[@id='m2EMDDeviceStatusFound-button']//option[2]";
								((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();",
										driver.findElement(By.xpath(statusFound)));
								Webdriver_waitToClick(statusFound);
								driver.findElement(By.xpath(statusFound)).click();
								
								//Status Left selection
								driver.findElement(By.xpath("//div[@id='m2EMDDeviceStatusLeft-button']//select")).click();
								String statusLeft = "//div[@id='m2EMDDeviceStatusLeft-button']//option[2]";
								((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();",
										driver.findElement(By.xpath(statusLeft)));
								Webdriver_waitToClick(statusLeft);
								driver.findElement(By.xpath(statusLeft)).click();
								
								//Entering kwh Reading:
								String kwh ="//div[@id='m2EMDivReadings']//span[text()='KWH']";
								Webdriver_waitToClick(kwh);
								((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();",
										driver.findElement(By.xpath(kwh)));
								driver.findElement(By.xpath(kwh)).click();
								String kwhReading ="//input[@id='m2RRReading']";
								Webdriver_waitToClick(kwhReading);
								driver.findElement(By.xpath(kwhReading)).sendKeys("123");
								HybridMCP_processAction();	
								
								String completeButton = "//span[text()='Complete']";								
								((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();",
										driver.findElement(By.xpath(completeButton)));
								Webdriver_waitToClick(completeButton);
								driver.findElement(By.xpath(completeButton)).click();
								
						   } catch (Exception e) {
								fail(e.getMessage());
								InfoDescription = e.getMessage();
								logComments(InfoDescription, CONST_FAILED);
							}
						}
				
				//Completes Disconnect Meter
				public void HybridBrowser_completeDisconnectMeterActivity() throws Exception {
							try {
								
								String modifiedDropdown = "//div[@class='ui-block-b']//span[text()='Modified']";
								Webdriver_waitToClick(modifiedDropdown);
								driver.findElement(By.xpath(modifiedDropdown)).click();
								
								String badgeNumber = "//input[@id='m2EMMBadgeNumber']";
								Webdriver_waitToClick(badgeNumber);
								driver.findElement(By.xpath(badgeNumber)).sendKeys("43534");
								Thread.sleep(1000);
								driver.findElement(By.xpath("//div[@id='m2EMMMeterConfigurationType-button']//select")).click();
								String configurationType = "//div[@id='m2EMMMeterConfigurationType-button']//option[6]";
								((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();",
										driver.findElement(By.xpath(configurationType)));
								Webdriver_waitToClick(configurationType);
								driver.findElement(By.xpath(configurationType)).click();
								
								//DisConnect Location selection
								driver.findElement(By.xpath("//div[@id='m2SPCmpDisconnectLocation-button']//select")).click();
								String disconnectLocation = "//div[@id='m2SPCmpDisconnectLocation-button']//option[2]";
								((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();",
										driver.findElement(By.xpath(disconnectLocation)));
								Webdriver_waitToClick(disconnectLocation);
								driver.findElement(By.xpath(disconnectLocation)).click();
								
								//Status Found selection
								driver.findElement(By.xpath("//div[@id='m2EMDDeviceStatusFound-button']//select")).click();
								String statusFound = "//div[@id='m2EMDDeviceStatusFound-button']//option[2]";
								((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();",
										driver.findElement(By.xpath(statusFound)));
								Webdriver_waitToClick(statusFound);
								driver.findElement(By.xpath(statusFound)).click();
								
								//Status Left selection
								driver.findElement(By.xpath("//div[@id='m2EMDDeviceStatusLeft-button']//select")).click();
								String statusLeft = "//div[@id='m2EMDDeviceStatusLeft-button']//option[2]";
								((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();",
										driver.findElement(By.xpath(statusLeft)));
								Webdriver_waitToClick(statusLeft);
								driver.findElement(By.xpath(statusLeft)).click();
								
								//Entering kwh Reading:
								String kwh ="//div[@id='m2EMDivReadings']//span[text()='KWH']";
								Webdriver_waitToClick(kwh);
								((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();",
										driver.findElement(By.xpath(kwh)));
								driver.findElement(By.xpath(kwh)).click();
								String kwhReading ="//input[@id='m2RRReading']";
								Webdriver_waitToClick(kwhReading);
								driver.findElement(By.xpath(kwhReading)).sendKeys("123");
								HybridMCP_processAction();
								
								String completeButton = "//span[text()='Complete']";								
								((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();",
										driver.findElement(By.xpath(completeButton)));
								Webdriver_waitToClick(completeButton);
								driver.findElement(By.xpath(completeButton)).click();
								
						   } catch (Exception e) {
								fail(e.getMessage());
								InfoDescription = e.getMessage();
								logComments(InfoDescription, CONST_FAILED);
							}
						}
				
				//Completes Exchnage Meter
				public void HybridBrowser_completeExchangeMeterActivity() throws Exception {
							try {
								
								String modifiedDropdown = "//div[@class='ui-block-b']//span[text()='Modified']";
								Webdriver_waitToClick(modifiedDropdown);
								driver.findElement(By.xpath(modifiedDropdown)).click();
								
								String badgeNumber = "//input[@id='m2EMMBadgeNumber']";
								Webdriver_waitToClick(badgeNumber);
								driver.findElement(By.xpath(badgeNumber)).sendKeys("43534");
								Thread.sleep(1000);
								//Select Configuration Type
								driver.findElement(By.xpath("//div[@id='m2EMMMeterConfigurationType-button']//select")).click();
								String configurationType = "//div[@id='m2EMMMeterConfigurationType-button']//option[6]";
								((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();",
										driver.findElement(By.xpath(configurationType)));
								Webdriver_waitToClick(configurationType);
								driver.findElement(By.xpath(configurationType)).click();
								
								//Status Found selection
								driver.findElement(By.xpath("//div[@id='m2EMDDeviceStatusFound-button']//select")).click();
								String statusFound = "//div[@id='m2EMDDeviceStatusFound-button']//option[2]";
								((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();",
										driver.findElement(By.xpath(statusFound)));
								Webdriver_waitToClick(statusFound);
								driver.findElement(By.xpath(statusFound)).click();
								
								//Status Left selection
								driver.findElement(By.xpath("//div[@id='m2EMDDeviceStatusLeft-button']//select")).click();
								String statusLeft = "//div[@id='m2EMDDeviceStatusLeft-button']//option[2]";
								((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();",
										driver.findElement(By.xpath(statusLeft)));
								Webdriver_waitToClick(statusLeft);
								driver.findElement(By.xpath(statusLeft)).click();
								
								//Entering kwh Reading:
								String kwh ="//div[@id='m2EMDivReadings']//span[text()='KWH']";
								Webdriver_waitToClick(kwh);
								((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();",
										driver.findElement(By.xpath(kwh)));
								driver.findElement(By.xpath(kwh)).click();
								String kwhReading ="//input[@id='m2RRReading']";
								Webdriver_waitToClick(kwhReading);
								driver.findElement(By.xpath(kwhReading)).sendKeys("123");
								
								//Badge Number in New Meter Details
								String newBadgeNumber = "//input[@id='m2NMBadgeNum']";
								Webdriver_waitToClick(newBadgeNumber);
								driver.findElement(By.xpath(newBadgeNumber)).sendKeys("43534");
								driver.findElement(By.xpath("//input[@id='m2NMBtnVerify']")).click();
								Thread.sleep(1000);
								driver.findElement(By.xpath("//div[@id='m2NMErrorTextDiv']/following-sibling::aside//a[text()='Overridden']")).click();
								Thread.sleep(1000);			
								//Select new meter Configuration Type
								driver.findElement(By.xpath("//div[@id='m2NMMMeterConfigurationType-button']//select")).click();
								String newMeterConfigurationType = "//div[@id='m2NMMMeterConfigurationType-button']//option[6]";
								((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();",
										driver.findElement(By.xpath(newMeterConfigurationType)));
								Webdriver_waitToClick(newMeterConfigurationType);
								driver.findElement(By.xpath(newMeterConfigurationType)).click();
								
								//Status Left selection for new meter
								driver.findElement(By.xpath("//div[@id='m2NMDeviceStatusLeft-button']//select")).click();
								String newMeterStatusLeft = "//div[@id='m2NMDeviceStatusLeft-button']//option[2]";
								((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();",
										driver.findElement(By.xpath(newMeterStatusLeft)));
								Webdriver_waitToClick(newMeterStatusLeft);
								driver.findElement(By.xpath(newMeterStatusLeft)).click();
								
								//Entering kwh Reading:
								String newMeterKWH ="//div[@id='m2NMDivReadings']//span[text()='KWH']";
								Webdriver_waitToClick(kwh);
								((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();",
										driver.findElement(By.xpath(newMeterKWH)));
								driver.findElement(By.xpath(newMeterKWH)).click();
								String newMeterKWHReading ="//input[@id='m2NMRRReading']";
								Webdriver_waitToClick(newMeterKWHReading);
								driver.findElement(By.xpath(newMeterKWHReading)).sendKeys("123");					
								HybridMCP_processAction();	
								
								String completeButton = "//span[text()='Complete']";								
								((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();",
										driver.findElement(By.xpath(completeButton)));
								Webdriver_waitToClick(completeButton);
								driver.findElement(By.xpath(completeButton)).click();
								
						   } catch (Exception e) {
								fail(e.getMessage());
								InfoDescription = e.getMessage();
								logComments(InfoDescription, CONST_FAILED);
							}
						}
	
				//Completes Basic Item
				public void HybridBrowser_completeBasicItemActivity() throws Exception {
							try {
								try {
								String modifiedDropdown = "//div[@class='ui-block-b']//span[text()='Modified']";
								Webdriver_waitToClick(modifiedDropdown);
								driver.findElement(By.xpath(modifiedDropdown)).click();
								}catch(Exception e) {
									
								}								
								//Status Found selection
								Webdriver_waitToClick("//div[@id='m2EIDeviceStatusFound-button']//select");
								driver.findElement(By.xpath("//div[@id='m2EIDeviceStatusFound-button']//select")).click();
								String statusFound = "//div[@id='m2EIDeviceStatusFound-button']//option[2]";
								((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();",
										driver.findElement(By.xpath(statusFound)));
								Webdriver_waitToClick(statusFound);
								driver.findElement(By.xpath(statusFound)).click();
								
								//Status Left selection
								Webdriver_waitToClick("//div[@id='m2EIDeviceStatusLeft-button']//select");
								driver.findElement(By.xpath("//div[@id='m2EIDeviceStatusLeft-button']//select")).click();
								String statusLeft = "//div[@id='m2EIDeviceStatusLeft-button']//option[2]";
								((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();",
										driver.findElement(By.xpath(statusLeft)));
								Webdriver_waitToClick(statusLeft);
								driver.findElement(By.xpath(statusLeft)).click();
								
								String completeButton = "//span[text()='Complete']";								
								((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();",
										driver.findElement(By.xpath(completeButton)));
								Webdriver_waitToClick(completeButton);
								driver.findElement(By.xpath(completeButton)).click();
								
								
						   } catch (Exception e) {
								fail(e.getMessage());
								InfoDescription = e.getMessage();
								logComments(InfoDescription, CONST_FAILED);
							}
						}
				
				//Completes Electric Disconnect Service
				public void HybridBrowser_completeDisconnectService() throws Exception {
							try {
								String modifiedDropdown = "//div[@class='ui-block-b']//span[text()='Modified']";
								Webdriver_waitToClick(modifiedDropdown);
								driver.findElement(By.xpath(modifiedDropdown)).click();
								
								//DisConnect Location selection
								Webdriver_waitToClick("//div[@id='m2SPCmpDisconnectLocation-button']//select//option");
								driver.findElement(By.xpath("//div[@id='m2SPCmpDisconnectLocation-button']//select//option")).click();
								String disconnectLocation = "//div[@id='m2SPCmpDisconnectLocation-button']//option[2]";
								((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();",
										driver.findElement(By.xpath(disconnectLocation)));
								Webdriver_waitToClick(disconnectLocation);
								driver.findElement(By.xpath(disconnectLocation)).click();								
								
								String completeButton = "//span[text()='Complete']";								
								((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();",
										driver.findElement(By.xpath(completeButton)));
								Webdriver_waitToClick(completeButton);
								driver.findElement(By.xpath(completeButton)).click();
								
								
						   } catch (Exception e) {
								fail(e.getMessage());
								InfoDescription = e.getMessage();
								logComments(InfoDescription, CONST_FAILED);
							}
						}
				
				//Completes Electric Install Meter
				public void HybridBrowser_completeExchangeItemActivity() throws Exception {
					try {
						
						String badgeNumber = "//input[@id='m2NIBadgeNum']";
						Webdriver_waitToClick(badgeNumber);
						driver.findElement(By.xpath(badgeNumber)).click();
						driver.findElement(By.xpath(badgeNumber)).sendKeys("43534");
						driver.findElement(By.xpath("//a[@id='m2NIBtnVerify']")).click();
						Thread.sleep(1000);
						driver.findElement(By.xpath("//a[text()='Overridden']")).click();
						Thread.sleep(1000);
						driver.findElement(By.xpath("//div[@id='m2NIDeviceStatusLeft-button']//select")).click();
						String statusLeft = "//div[@id='m2NIDeviceStatusLeft-button']//option[2]";
						((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();",
								driver.findElement(By.xpath(statusLeft)));
						//Webdriver_waitToClick(statusLeft);
						driver.findElement(By.xpath(statusLeft)).click();
						completeButton();

					} catch (Exception e) {
						fail(e.getMessage());
						InfoDescription = e.getMessage();
						logComments(InfoDescription, CONST_FAILED);
					}
				}
				
				//Completes Electric Disconnect Item
				public void HybridBrowser_completeElectricDisconnectItemActivity() throws Exception {
					try {
						
						//DisConnect Location selection
						driver.findElement(By.xpath("//div[@id='m2SPCmpDisconnectLocation-button']//select")).click();
						String disconnectLocation = "//div[@id='m2SPCmpDisconnectLocation-button']//option[2]";
						((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();",
								driver.findElement(By.xpath(disconnectLocation)));
						Webdriver_waitToClick(disconnectLocation);
						driver.findElement(By.xpath(disconnectLocation)).click();
						
						//Status Found selection
						driver.findElement(By.xpath("//div[@id='m2EIDeviceStatusFound-button']//select")).click();
						String statusFound = "//div[@id='m2EIDeviceStatusFound-button']//option[2]";
						((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();",
								driver.findElement(By.xpath(statusFound)));
						Webdriver_waitToClick(statusFound);
						driver.findElement(By.xpath(statusFound)).click();
						
						//Status Left selection
						driver.findElement(By.xpath("//div[@id='m2EIDeviceStatusLeft-button']//select")).click();
						String statusLeft = "//div[@id='m2EIDeviceStatusLeft-button']//option[2]";
						((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();",
								driver.findElement(By.xpath(statusLeft)));
						Webdriver_waitToClick(statusLeft);
						driver.findElement(By.xpath(statusLeft)).click();
						
						completeButton();

					} catch (Exception e) {
						fail(e.getMessage());
						InfoDescription = e.getMessage();
						logComments(InfoDescription, CONST_FAILED);
					}
				}
	//Completes M2 Activity in browser
	public void HybridMCP_M2Complete() throws Exception {
		try {
			
			String badgeNumber = "//input[@id='m2NIBadgeNum']";
			Webdriver_waitToClick(badgeNumber);
			driver.findElement(By.xpath(badgeNumber)).sendKeys("43534");
			driver.findElement(By.xpath("//a[@id='m2NIBtnVerify']")).click();
			Thread.sleep(1000);
			driver.findElement(By.xpath("//a[text()='Overridden']")).click();
			Thread.sleep(1000);
			driver.findElement(By.xpath("//div[@id='m2NIDeviceStatusLeft-button']//select")).click();
			String statusLeft = "//div[@id='m2NIDeviceStatusLeft-button']//option[2]";
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();",
					driver.findElement(By.xpath(statusLeft)));
			//Webdriver_waitToClick(statusLeft);
			driver.findElement(By.xpath(statusLeft)).click();
			// clicking on activity dropdown324534
			String completeButton = "//span[text()='Complete']";
			
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();",
					driver.findElement(By.xpath(completeButton)));
			Webdriver_waitToClick(completeButton);
			driver.findElement(By.xpath(completeButton)).click();

		} catch (Exception e) {
			fail(e.getMessage());
			InfoDescription = e.getMessage();
			logComments(InfoDescription, CONST_FAILED);
		}
	}
    
	public String HybridMCP_AddRelatedActivity(String activityType, String wStatus) throws Exception {
		try {
			String pageMenuButton = "//a[@id='pageMenuButton']";
			Webdriver_waitToClick(pageMenuButton);
			driver.findElement(MobileBy.id("pageMenuButton")).click();
			switchToWebView();
			String addActivity = "//span[text()='Add Activity']";
			Webdriver_waitToClick(addActivity);
			driver.findElement(By.xpath(addActivity)).click();
			HybridMCP_scrollAndSelectDropdown(activityType);
			HybridMCP_processAction();
			String addButton = "//a[@id='m1PkActBtnAdd']";
			Webdriver_waitToClick(addButton);
			HybridMCP_selectWorkStatus(wStatus);
			driver.findElement(By.xpath(addButton)).click();
			Webdriver_waitToClick("//a[@id='pageMenuButton']");

		} catch (Exception e) {
			fail(e.getMessage());
			InfoDescription = e.getMessage();
			logComments(InfoDescription, CONST_FAILED);
			return "N";
		}
		return "N";
	}
	
	public String HybridBrowser_activityWithRelatedPickUp(String activityType, String wStatus) throws Exception {

  		try { 
  			int count = HybridMCP_listOfActivities();
  			String tasks = "//ul[@id='tasklistview']//li[@class='ui-first-child']/a";
  			Webdriver_waitToClick(tasks);
  			driver.findElement(By.xpath(tasks)).click();
  			HybridBrowser_AddRelatedActivity(activityType, wStatus);
  		    // Complete the Parent Activity
  			
  			HybridMCP_clickOnEnRoute();
  			HybridMCP_clickStartAtWorkSite();
  			HybridMCP_M2Complete();
  		    // Completing the Related Activity
  			try {
  				HybridMCP_M2Complete();
  			}catch(Exception e) {
  				
  			} 
  			} catch (Exception e) {
  			
  		}
  		return "N";
  	
 	}
	
	//Component for creating Basic Item Related Pickup activity when created 
	//Disconnect Service Activity in server.
	public String HybridBrowser_disconnectServiceBasicItemRelatedPickUp(String activityType, String wStatus) throws Exception {

  		try { 
  			//int count = HybridMCP_listOfActivities();
  			String tasks = "//ul[@id='tasklistview']//li[@class='ui-first-child']/a";
  			Webdriver_waitToClick(tasks);
  			driver.findElement(By.xpath(tasks)).click();
  			HybridBrowser_AddRelatedActivity(activityType, wStatus);
  			// Completing the Related Activity
  			HybridMCP_clickOnEnRoute();
  			HybridMCP_clickStartAtWorkSite();
  			HybridBrowser_completeDisconnectService();
  			HybridBrowser_completeBasicItemActivity();
  			//HybridMCP_M2Complete();
  			// Complete the Parent Activity
  			try {
  				HybridMCP_M2Complete();
  			}catch(Exception e) {
  				
  			}
  			
  			try {
  				String completeButton = "//span[text()='Complete']";
  				
  				((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();",
  						driver.findElement(By.xpath(completeButton)));
  				Webdriver_waitToClick(completeButton);
  				driver.findElement(By.xpath(completeButton)).click();
  			}catch(Exception e) {
  				
  			}
  		} catch (Exception e) {
  			
  		}
  		return "N";
  	
 	}	
	
	public void completeButton() {
		String completeButton = "//span[text()='Complete']";
			
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();",
					driver.findElement(By.xpath(completeButton)));
			Webdriver_waitToClick(completeButton);
			driver.findElement(By.xpath(completeButton)).click();
	}
	
	//
		public String HybridBrowser_exchangeItemDisconnectItemRelatedPickUp(String activityType, String wStatus) throws Exception {

	  		try { 
	  			//int count = HybridMCP_listOfActivities();
	  			String tasks = "//ul[@id='tasklistview']//li[@class='ui-first-child']/a";
	  			Webdriver_waitToClick(tasks);
	  			driver.findElement(By.xpath(tasks)).click();
	  			HybridBrowser_AddRelatedActivity(activityType, wStatus);
	  			// Completing the Related Activity
	  			HybridMCP_clickOnEnRoute();
	  			HybridMCP_clickStartAtWorkSite();
	  			HybridBrowser_completeElectricDisconnectItemActivity();
	  			HybridBrowser_completeExchangeItemActivity();
	  			//HybridBrowser_completeElectricDisconnectItemActivity();
	  			//Completing Parent Activity
	  			//completeButton();
	  		} catch (Exception e) {
	  			
	  		}
	  		return "N";	  	
	 	}
		
		//Exchange Item Activity in server.
				public String HybridBrowser_exchangeItemCutForNonPaymentRelatedPickUp(String activityType, String wStatus) throws Exception {

			  		try { 
			  			//int count = HybridMCP_listOfActivities();
			  			String tasks = "//ul[@id='tasklistview']//li[@class='ui-first-child']/a";
			  			Webdriver_waitToClick(tasks);
			  			driver.findElement(By.xpath(tasks)).click();
			  			HybridBrowser_AddRelatedActivity(activityType, wStatus);
			  			// Completing the Related Activity
			  			HybridMCP_clickOnEnRoute();
			  			HybridMCP_clickStartAtWorkSite();
			  			HybridBrowser_completeExchangeItemActivity();
			  			//Completing Parent Activity
			  			completeButton();
			  		} catch (Exception e) {
			  			
			  		}
			  		return "N";	  	
			 	}
				
				//Exchange Item Activity in server.
				public String HybridBrowser_exchangeMeterCutForNonPaymentRelatedPickUp(String activityType, String wStatus) throws Exception {

			  		try { 
			  			//int count = HybridMCP_listOfActivities();
			  			String tasks = "//ul[@id='tasklistview']//li[@class='ui-first-child']/a";
			  			Webdriver_waitToClick(tasks);
			  			driver.findElement(By.xpath(tasks)).click();
			  			HybridBrowser_AddRelatedActivity(activityType, wStatus);
			  			// Completing the Related Activity
			  			HybridMCP_clickOnEnRoute();
			  			HybridMCP_clickStartAtWorkSite();
			  			HybridBrowser_completeExchangeMeterActivity();
			  			//Completing Parent Activity
			  			completeButton();
			  		} catch (Exception e) {
			  			
			  		}
			  		return "N";	  	
			 	}
				
				//Adds DisconnectItem related pick activity for Remove Item Created at server
				public String HybridBrowser_removeItemDisconnectItemRelatedPickUp(String activityType, String wStatus) throws Exception {

			  		try { 
			  			//int count = HybridMCP_listOfActivities();
			  			String tasks = "//ul[@id='tasklistview']//li[@class='ui-first-child']/a";
			  			Webdriver_waitToClick(tasks);
			  			driver.findElement(By.xpath(tasks)).click();
			  			HybridBrowser_AddRelatedActivity(activityType, wStatus);
			  			// Completing the Related Activity
			  			HybridMCP_clickOnEnRoute();
			  			HybridMCP_clickStartAtWorkSite();
			  			//Completed Remove Item Activity
			  			HybridMCP_M2Complete();
			  			HybridBrowser_completeElectricDisconnectItemActivity();
			  		} catch (Exception e) {
			  			
			  		}
			  		return "N";	  	
			 	}
		
				
				//Adds Disconnect Meter related pick activity for Remove Meter Created at server
				public String HybridBrowser_removeMeterDisconnectMeterRelatedPickUp(String activityType, String wStatus) throws Exception {

			  		try { 
			  			//int count = HybridMCP_listOfActivities();
			  			String tasks = "//ul[@id='tasklistview']//li[@class='ui-first-child']/a";
			  			Webdriver_waitToClick(tasks);
			  			driver.findElement(By.xpath(tasks)).click();
			  			HybridBrowser_AddRelatedActivity(activityType, wStatus);
			  			// Completing the Related Activity
			  			HybridMCP_clickOnEnRoute();
			  			HybridMCP_clickStartAtWorkSite();
			  			//Completed Remove Meter Activity
			  			HybridBrowser_completeRemoveMeterActivity();
			  			HybridBrowser_completeDisconnectMeterActivity();
			  		} catch (Exception e) {
			  			
			  		}
			  		return "N";	  	
			 	}
				
				//Adds Disconnect Service related pick activity for Connect Service Created at server
				public String HybridBrowser_connectServiceDisconnectServiceRelatedPickUp(String activityType, String wStatus) throws Exception {

			  		try { 
			  			//int count = HybridMCP_listOfActivities();
			  			String tasks = "//ul[@id='tasklistview']//li[@class='ui-first-child']/a";
			  			Webdriver_waitToClick(tasks);
			  			driver.findElement(By.xpath(tasks)).click();
			  			HybridBrowser_AddRelatedActivity(activityType, wStatus);
			  			// Completing the Related Activity
			  			HybridMCP_clickOnEnRoute();
			  			HybridMCP_clickStartAtWorkSite();
			  			//Completed Connect Service Activity
			  			completeButton();
			  			HybridBrowser_completeDisconnectService();
			  		} catch (Exception e) {
			  			
			  		}
			  		return "N";	  	
			 	}
				
				//Adds Exchange Meter related pick activity for Disconnect Meter Created at server
				public String HybridBrowser_disconnectMeterExchangeMeterRelatedPickUp(String activityType, String wStatus) throws Exception {

			  		try { 
			  			//int count = HybridMCP_listOfActivities();
			  			String tasks = "//ul[@id='tasklistview']//li[@class='ui-first-child']/a";
			  			Webdriver_waitToClick(tasks);
			  			driver.findElement(By.xpath(tasks)).click();
			  			HybridBrowser_AddRelatedActivity(activityType, wStatus);
			  			// Completing the Related Activity
			  			HybridMCP_clickOnEnRoute();
			  			HybridMCP_clickStartAtWorkSite();
			  		//Completed Connect Service Activity
			  			completeButton();
			  			HybridBrowser_completeDisconnectMeterActivity();
			  			HybridBrowser_completeExchangeMeterActivity();
			  		} catch (Exception e) {
			  			
			  		}
			  		return "N";	  	
			 	}
				
				//Adds Install related pick activity for Cut For Non Payment Created at server
				public String HybridBrowser_cutForNonPaymentInstallItemRelatedPickUp(String activityType, String wStatus) throws Exception {

			  		try { 
			  			//int count = HybridMCP_listOfActivities();
			  			String tasks = "//ul[@id='tasklistview']//li[@class='ui-first-child']/a";
			  			Webdriver_waitToClick(tasks);
			  			driver.findElement(By.xpath(tasks)).click();
			  			HybridBrowser_AddRelatedActivity(activityType, wStatus);
			  			// Completing the Related Activity
			  			HybridMCP_clickOnEnRoute();
			  			HybridMCP_clickStartAtWorkSite();
			  			//Completed cut for non payment Activity
			  			completeButton();
			  			HybridMCP_M2Complete();
			  		} catch (Exception e) {
			  			
			  		}
			  		return "N";	  	
			 	}
				
				//Adds Meter Read pick activity for Cut For Non Payment Created at server
				public String HybridBrowser_cutForNonPaymentMeterReadRelatedPickUp(String activityType, String wStatus) throws Exception {

			  		try { 
			  			//int count = HybridMCP_listOfActivities();
			  			String tasks = "//ul[@id='tasklistview']//li[@class='ui-first-child']/a";
			  			Webdriver_waitToClick(tasks);
			  			driver.findElement(By.xpath(tasks)).click();
			  			HybridBrowser_AddRelatedActivity(activityType, wStatus);
			  			// Completing the Related Activity
			  			HybridMCP_clickOnEnRoute();
			  			HybridMCP_clickStartAtWorkSite();
			  			//Completed cut for non payment Activity
			  			completeButton();
			  			HybridBrowser_completeMeterReadActivity();
			  		} catch (Exception e) {
			  			
			  		}
			  		return "N";	  	
			 	}
				
				//Adds Remove Item pick activity for basic item Created at server
				public String HybridBrowser_basicItemRemoveItemRelatedPickUp(String activityType, String wStatus) throws Exception {

			  		try { 
			  			//int count = HybridMCP_listOfActivities();
			  			String tasks = "//ul[@id='tasklistview']//li[@class='ui-first-child']/a";
			  			Webdriver_waitToClick(tasks);
			  			driver.findElement(By.xpath(tasks)).click();
			  			HybridBrowser_AddRelatedActivity(activityType, wStatus);
			  			// Completing the Related Activity
			  			HybridMCP_clickOnEnRoute();
			  			HybridMCP_clickStartAtWorkSite();
			  			//Completed basic item Activity
			  			HybridBrowser_completeBasicItemActivity();
			  			HybridMCP_M2Complete();
			  		} catch (Exception e) {
			  			
			  		}
			  		return "N";	  	
			 	}
				
				//Adds Remove Meter pick activity for Meter Read Created at server
				public String HybridBrowser_meterReadRemoveMeterRelatedPickUp(String activityType, String wStatus) throws Exception {

			  		try { 
			  			//int count = HybridMCP_listOfActivities();
			  			String tasks = "//ul[@id='tasklistview']//li[@class='ui-first-child']/a";
			  			Webdriver_waitToClick(tasks);
			  			driver.findElement(By.xpath(tasks)).click();
			  			HybridBrowser_AddRelatedActivity(activityType, wStatus);
			  			// Completing the Related Activity
			  			HybridMCP_clickOnEnRoute();
			  			HybridMCP_clickStartAtWorkSite();
			  			//Completes Meter Read Activity
			  			HybridBrowser_completeMeterReadActivity();
			  			HybridBrowser_completeRemoveMeterActivity();
			  		} catch (Exception e) {
			  			
			  		}
			  		return "N";	  	
			 	}
				
				//Add and complete Un Related Pick Up activity
				public String HybridBrowserM2_addAndCompleteUnRelatedPickUp(String activityType, String address, String city, String country,
						String state, String workStatus) throws Exception {
			  		try { 			  			
			  			HybridMCPM2_addUnRelatedPickUpActivity(activityType,address,city,country,state,workStatus);
			  			//int count = HybridMCP_listOfActivities();
			  			String tasks = "//ul[@id='tasklistview']//li[@class='ui-first-child']/a";
			  			Webdriver_waitToClick(tasks);
			  			driver.findElement(By.xpath(tasks)).click();
			  			// Completing the Related Activity
			  			HybridMCP_clickOnEnRoute();
			  			HybridMCP_clickStartAtWorkSite();
			  			HybridBrowser_completeBasicItemActivity();
			  		} catch (Exception e) {
			  			
			  		}
			  		return "N";	  	
			 	}
				
				//Adds Disconnect Service related pick activity for Connect Service Created at server
				public String HybridBrowser_passProcedure() throws Exception {

			  		try { 	  			  			
			  			//Pass Failed Procedure
			  			String OpenTasks = "//ul[@id='tasklistview']//li[@class='ui-first-child']/a";
			  			Webdriver_waitToClick(OpenTasks);
			  			driver.findElement(By.xpath(OpenTasks)).click();
			  			String pageButton = "//a[@id='pageMenuButton']";
			  			Webdriver_waitToVisible(pageButton);
			  			String startButton = "//span[text()='Start']";
						
						((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();",
								driver.findElement(By.xpath(startButton)));
						Webdriver_waitToClick(startButton);
						driver.findElement(By.xpath(startButton)).click();
						
						String pendingButton = "//span[text()='Pending']";
						Webdriver_waitToClick(pendingButton);
						driver.findElement(By.xpath(pendingButton)).click();
						
						
						String yesButton = "//a[text()='Yes']";
						Webdriver_waitToClick(yesButton);
						driver.findElement(By.xpath(yesButton)).click();
						
						String okButton = "//span[text()='Ok']";
						Webdriver_waitToClick(okButton);
						driver.findElement(By.xpath(okButton)).click();
						
						String completeButton = "//span[text()='Complete']";								
						((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();",
								driver.findElement(By.xpath(completeButton)));
						Webdriver_waitToClick(completeButton);
						driver.findElement(By.xpath(completeButton)).click();
						Webdriver_waitToVisible(pageButton);
						
			  		} catch (Exception e) {
			  			
			  		}
			  		return "N";	  	
			 	}
				
				//Clicks on single task item available in open tasks list
				public String HybridBrowser_clickOnSingleTaskItem() throws Exception {
					try {		
						
			  			String tasks = "//ul[@id='tasklistview']//li[@class='ui-first-child']/a";
			  			Webdriver_waitToClick(tasks);
			  			driver.findElement(By.xpath(tasks)).click();
			  			String pageButton = "//a[@id='pageMenuButton']";
			  			Webdriver_waitToVisible(pageButton);
			  			
			  		} catch (Exception e) {
			  			
			  		}
			  		return "N";	  
				
				}
				
				// Click on pending button
				public void HybridMCP_clickOnPendingButton() throws Exception {
					try {
						// clicking on pending button
						String pendingButton = "//span[text()='Pending']";
						Webdriver_waitToClick(pendingButton);
						driver.findElement(By.xpath(pendingButton)).click();

					} catch (Exception e) {
						fail(e.getMessage());
						InfoDescription = e.getMessage();
						logComments(InfoDescription, CONST_FAILED);
					}
				}
				
				// Click on ok button
				public void HybridMCP_clickOnOkButton() throws Exception {
					try {
						// clicking on OK button
						String okButton = "//span[text()='Ok']";
						Webdriver_waitToClick(okButton);
						driver.findElement(By.xpath(okButton)).click();

					} catch (Exception e) {
						fail(e.getMessage());
						InfoDescription = e.getMessage();
						logComments(InfoDescription, CONST_FAILED);
					}
				}
				
				// Click on ok button
				public void HybridMCP_clickOnYesButton() throws Exception {
					try {
						// clicking on OK button
						String okButton = "//span[text()='Ok']";
						Webdriver_waitToClick(okButton);
						driver.findElement(By.xpath(okButton)).click();

					} catch (Exception e) {
						fail(e.getMessage());
						InfoDescription = e.getMessage();
						logComments(InfoDescription, CONST_FAILED);
					}
				}
				
				// Click on Accept button
				public void HybridMCP_clickOnAcceptButton() throws Exception {
					try {
						// clicking on Accept button
						String acceptButton = "//span[text()='Accept']";
						Webdriver_waitToClick(acceptButton);
						driver.findElement(By.xpath(acceptButton)).click();
						
						String pageButton = "//a[@id='pageMenuButton']";
			  			Webdriver_waitToVisible(pageButton);

					} catch (Exception e) {
						fail(e.getMessage());
						InfoDescription = e.getMessage();
						logComments(InfoDescription, CONST_FAILED);
					}
				}
				
				// Click on back button in navigation bar
				public void HybridMCP_clickOnBackButtonInNavigationBar() throws Exception {
					try {
						
						String backButton = "//div[not(contains(@id,'login'))]/div//a[@id='goBack-href']";
			  			Webdriver_waitToClick(backButton);
			  			
			  			driver.findElement(By.xpath(backButton)).click();
			  			//Thread.sleep(10000);
			  			Webdriver_waitToVisible("//a[@id='pageMenuButton']");

					} catch (Exception e) {
						fail(e.getMessage());
						InfoDescription = e.getMessage();
						logComments(InfoDescription, CONST_FAILED);
					}
				}
				
				//Adds Disconnect Service related pick activity for Connect Service Created at server
				public String HybridBrowser_failProcedure() throws Exception {

			  		try { 
			  			//int count = HybridMCP_listOfActivities();
			  			//HybridMCP_addUnRelatedPickUpActivity(activityType,address,city,country,state,workStatus);
			  						  			
			  			String tasks = "//ul[@id='tasklistview']//li[@class='ui-first-child']/a";
			  			Webdriver_waitToClick(tasks);
			  			driver.findElement(By.xpath(tasks)).click();
			  			
			  			//HybridBrowser_AddRelatedActivity(activityType, wStatus);
			  			//Fail procedure
			  			HybridMCP_clickOnEnRoute();
			  			HybridMCP_clickStartAtWorkSite();
			  									
						String pendingButton = "//span[text()='Pending']";
						Webdriver_waitToClick(pendingButton);
						driver.findElement(By.xpath(pendingButton)).click();
						
						String okButton = "//span[text()='Ok']";
						Webdriver_waitToClick(okButton);
						driver.findElement(By.xpath(okButton)).click();
						
						String acceptButton = "//span[text()='Accept']";
						Webdriver_waitToClick(acceptButton);
						driver.findElement(By.xpath(acceptButton)).click();
						
						String pageButton = "//a[@id='pageMenuButton']";
			  			Webdriver_waitToVisible(pageButton);
			  			
			  			//String backButton = "//a[@id='goBack-href']";
			  			String backButton = "//div[not(contains(@id,'login'))]/div//a[@id='goBack-href']";
			  			Webdriver_waitToClick(backButton);
			  			
			  			driver.findElement(By.xpath(backButton)).click();
			  			Thread.sleep(10000);
			  			Webdriver_waitToVisible(pageButton);
						
			  		} catch (Exception e) {
			  			
			  		}
			  		return "N";	  	
			 	}
				
	//Selects required task type from dropdown in hybrid browser
	public void HybridBrowser_scrollAndSelectDropdown(String activityType) throws Exception {
		try {
			// clicking on activity dropdown
			//String activityDropdown = "//div[@id='m1SPkTargetTaskType-button']";
			//String activityDropdown = "//div[@id='tsklstSPkTargetTaskType-button']";
			String activityDropdown = "//div[@id='m1SPkTargetTaskType-button']//select//option";
			//Webdriver_waitToClick(activityDropdown);
			Thread.sleep(3000);
			driver.findElement(By.xpath(activityDropdown)).click();
			Thread.sleep(1000);

			// Scrolling and selecting the required dropdown value
			// String activityName =
			// "//select[@id='tsklstSPkTargetTaskType']//option[@value='"+activityType+"']";
			String activityName = "//*[text()='" + activityType + "']";
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();",
					driver.findElement(By.xpath(activityName)));
			Webdriver_waitToClick(activityName);
			driver.findElement(By.xpath(activityName)).click();
			
			

		} catch (Exception e) {
			fail(e.getMessage());
			InfoDescription = e.getMessage();
			logComments(InfoDescription, CONST_FAILED);
		}
	}
	
	
	
	//Selects required task type from dropdown in hybrid browser
		public void HybridMCPM2_scrollAndSelectDropdown(String activityType) throws Exception {
			try {
				
				String activityDropdown = "//div[@id='tsklstSPkTargetTaskType-button']//select";
				Thread.sleep(3000);
				driver.findElement(By.xpath(activityDropdown)).click();
				Thread.sleep(1000);
				String activityName = "//*[text()='" + activityType + "']";
				((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();",
						driver.findElement(By.xpath(activityName)));
				Webdriver_waitToClick(activityName);
				driver.findElement(By.xpath(activityName)).click();
			} catch (Exception e) {
				fail(e.getMessage());
				InfoDescription = e.getMessage();
				logComments(InfoDescription, CONST_FAILED);
			}
		}
	//Adds Releated activity in browser
	public String HybridBrowser_AddRelatedActivity(String activityType, String wStatus) throws Exception {
		try {
			String pageMenuButton = "//a[@id='pageMenuButton']";
			Webdriver_waitToClick(pageMenuButton);
			driver.findElement(By.xpath(pageMenuButton)).click();
			//switchToWebView();
			String addActivity = "//span[text()='Add Activity']";
			Webdriver_waitToClick(addActivity);
			driver.findElement(By.xpath(addActivity)).click();
			HybridBrowser_scrollAndSelectDropdown(activityType);			
			HybridMCP_processAction();
			String addButton = "//a[@id='m2PkActBtnAdd']";
			Webdriver_waitToClick(addButton);			
			HybridBrowser_selectWorkStatus(wStatus);
			String nbadgeNumber = "//input[@id='m2PkActItemBadgeNumber']";
			//Webdriver_waitToClick(badgeNumber);
			driver.findElement(By.xpath(nbadgeNumber)).click();
			driver.findElement(By.xpath(nbadgeNumber)).sendKeys("123");
			driver.findElement(By.xpath(addButton)).click();
			Webdriver_waitToClick("//a[@id='pageMenuButton']");

		} catch (Exception e) {
			fail(e.getMessage());
			InfoDescription = e.getMessage();
			logComments(InfoDescription, CONST_FAILED);
			return "N";
		}
		return "N";
	}

	public String HybridMCP_activityWithRelatedPickUp(String activityType, String wStatus) throws Exception {
		try {
            //switchToWebView();
            switchToWebWindow();
			int count = HybridMCP_listOfActivities();
			String tasks = "//ul[@id='tasklistview']//li[" + count + "]//span[contains(text(),'" + activityType + "')]";
			Webdriver_waitToClick(tasks);
			driver.findElement(By.xpath("//span[contains(text(),'" + activityType + "')]")).click();
			HybridMCP_AddRelatedActivity(activityType, wStatus);
			// Completing the Related Activity
			HybridMCP_clickOnEnRoute();
			HybridMCP_clickStartAtWorkSite();
			HybridMCP_clickCompleteButton();
			// Complete the Parent Activity
			HybridMCP_clickCompleteButton();
		} catch (Exception e) {
			fail(e.getMessage());
			InfoDescription = e.getMessage();
			logComments(InfoDescription, CONST_FAILED);
			return "N";
		}
		return "N";
	}

	// Validate if related activity is created
	public String HybridMCP_validateIfRelatedActivityIsCreated(String crewShiftId, String parentTaskId)
			throws Exception {

		try {
			String Query = "";

			Query = "SELECT * FROM M1_TASK WHERE MAN_ALLOC_TO_SHIFT = '" + crewShiftId + "' AND PARENT_TASK_ID = '"
					+ parentTaskId + "'";

			ResultSet lObjResultSet = (ResultSet) oUTSPCORELIB.executeSQLQry(Query);

			if (lObjResultSet != null) {
				while (lObjResultSet.next()) {

					String relatedActivityId = lObjResultSet.getString(1);

					if (!relatedActivityId.trim().equals("")) {
						return relatedActivityId;
					}
				}
				oUTSPCORELIB.closeConnection();
			}
			return "";
		} catch (Exception e) {
			fail("Exception in creating Related Activity : " + e.getMessage().toString());
			return "";
		}
	}

	public String HybridMCP_completeM1Activity() throws Exception {
		try {

			Thread.sleep(5000);

			WebElement completeButton = driver
					.findElement(By.xpath("//android.widget.Button[@content-desc ='Complete']"));
			Thread.sleep(2000);
			completeButton.click();

		} catch (Exception e) {
			fail(e.getMessage());
			InfoDescription = e.getMessage();
			logComments(InfoDescription, CONST_FAILED);
			return "N";
		}
		return "N";
	}

	public void Webdriver_waitToClick(String xpath) {
		try {
			WebDriverWait wait = new WebDriverWait(driver, 180);
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath(xpath)));
		} catch (Exception e) {
			fail(e.getMessage());
			InfoDescription = e.getMessage();
		}
	}

	public void Webdriver_waitToVisible(String xpath) {
		try {
			WebDriverWait wait = new WebDriverWait(driver, 300);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xpath)));
		} catch (Exception e) {
			fail(e.getMessage());
			InfoDescription = e.getMessage();
		}
	}

	public String Webdriver_addActivityKeepItWithCrew(String activityType) throws Exception {
		try {

			driver.findElement(MobileBy.id("pageMenuButton")).click();
			Thread.sleep(2000);
			driver.findElement(By.xpath("//span[text()='Add Activity']")).click();
			WebDriverWait wait = new WebDriverWait(driver, 20);
			wait.until(ExpectedConditions.elementToBeClickable(By.id("tsklstSPkTargetTaskType-button")));
			driver.findElement(By.id("tsklstSPkTargetTaskType-button")).click();
			String activityName = "//select[@id='tsklstSPkTargetTaskType']//option[@value='" + activityType + "']";
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();",
					driver.findElement(By.xpath(activityName)));
			driver.findElement(By.xpath(activityName)).click();
			String processActionButton = "//a[@id='processActionButton']";
			Webdriver_waitToClick(processActionButton);
			driver.findElement(By.xpath("//a[@id='processActionButton']")).click();
			String addressLabel = "//h2/span[@id='m1PkAdrAddress-lbl']";
			Webdriver_waitToClick(addressLabel);

			// Entering Address and City Name
			driver.findElement(By.xpath("//input[@id='m1PkAdrAddress']")).sendKeys("15315 Bartlett Ave");
			driver.findElement(By.xpath("//input[@id='m1PkAdrCity']")).sendKeys("Cleveland");

			// Selecting Country
			driver.findElement(By.xpath("//div[@id='m1PkAdrCountry-button']")).click();
			String countryName = "//div[@id='m1PkAdrCountry-button']//option[text()='United States of America']";
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();",
					driver.findElement(By.xpath(countryName)));
			driver.findElement(By.xpath(countryName)).click();

			// Selecting City
			driver.findElement(By.xpath("//div[@id='m1PkAdrState-button']")).click();
			String cityName = "//div[@id='m1PkAdrState-button']//option[text()='Ohio']";
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();",
					driver.findElement(By.xpath(cityName)));
			driver.findElement(By.xpath(cityName)).click();

			driver.findElement(By.xpath("//a[@id='m1PkAdrOKBtn']")).click();

			String addButton = "//a[@id='m1PkActBtnAdd']";
			Webdriver_waitToClick(addButton);

			// Selecting KeepWithCrew
			driver.findElement(MobileBy.id("m1PkActPickupStatus-button")).click();
			String workStatus = "//div[@id='m1PkActPickupStatus-button']//option[text()='Return But Keep With Crew']";
			Webdriver_waitToClick(workStatus);
			driver.findElement(By.xpath(workStatus)).click();
			driver.findElement(By.xpath(addButton)).click();

			Webdriver_waitToClick("//a[@id='pageMenuButton']");

		} catch (Exception e) {
			fail(e.getMessage());
			InfoDescription = e.getMessage();
			logComments(InfoDescription, CONST_FAILED);
			return "N";
		}
		return "N";
	}

	public String Webdriver_addActivityReturnIt(String activityType) throws Exception {
		try {

			driver.findElement(By.xpath("//a[@id='pageMenuButton']")).click();
			Thread.sleep(2000);
			;
			driver.findElement(By.xpath("//span[text()='Add Activity']")).click();
			WebDriverWait wait = new WebDriverWait(driver, 20);
			wait.until(ExpectedConditions.elementToBeClickable(By.id("tsklstSPkTargetTaskType-button")));
			driver.findElement(By.id("tsklstSPkTargetTaskType-button")).click();
			String activityName = "//select[@id='tsklstSPkTargetTaskType']//option[@value='" + activityType + "']";
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();",
					driver.findElement(By.xpath(activityName)));
			driver.findElement(By.xpath(activityName)).click();
			String processActionButton = "//a[@id='processActionButton']";
			Webdriver_waitToClick(processActionButton);
			driver.findElement(By.xpath("//a[@id='processActionButton']")).click();
			String addressLabel = "//h2/span[@id='m1PkAdrAddress-lbl']";
			Webdriver_waitToClick(addressLabel);

			// Entering Address and City Name
			driver.findElement(By.xpath("//input[@id='m1PkAdrAddress']")).sendKeys("16086 Hazel Rd");
			driver.findElement(By.xpath("//input[@id='m1PkAdrCity']")).sendKeys("Cleveland");

			// Selecting Country
			driver.findElement(By.xpath("//div[@id='m1PkAdrCountry-button']")).click();
			String countryName = "//div[@id='m1PkAdrCountry-button']//option[text()='United States of America']";
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();",
					driver.findElement(By.xpath(countryName)));
			driver.findElement(By.xpath(countryName)).click();

			// Selecting City
			driver.findElement(By.xpath("//div[@id='m1PkAdrState-button']")).click();
			String cityName = "//div[@id='m1PkAdrState-button']//option[text()='Ohio']";
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();",
					driver.findElement(By.xpath(cityName)));
			driver.findElement(By.xpath(cityName)).click();

			driver.findElement(By.xpath("//a[@id='m1PkAdrOKBtn']")).click();

			String addButton = "//a[@id='m1PkActBtnAdd']";
			Webdriver_waitToClick(addButton);

			// Selecting KeepWithCrew
			driver.findElement(By.xpath("m1PkActPickupStatus-button")).click();
			String workStatus = "//div[@id='m1PkActPickupStatus-button']//option[text()='Return It']";
			Webdriver_waitToClick(workStatus);
			driver.findElement(By.xpath(workStatus)).click();
			driver.findElement(By.xpath(addButton)).click();

			Webdriver_waitToClick("//a[@id='pageMenuButton']");

		} catch (Exception e) {
			fail(e.getMessage());
			InfoDescription = e.getMessage();
			logComments(InfoDescription, CONST_FAILED);
			return "N";
		}
		return "N";
	}

	public String Webdriver_addActivityWorkIt(String activityType) throws Exception {
		try {

			driver.findElement(By.xpath("//a[@id='pageMenuButton']")).click();
			Thread.sleep(2000);
			;
			driver.findElement(By.xpath("//span[text()='Add Activity']")).click();
			WebDriverWait wait = new WebDriverWait(driver, 20);
			wait.until(ExpectedConditions.elementToBeClickable(By.id("tsklstSPkTargetTaskType-button")));
			driver.findElement(By.id("tsklstSPkTargetTaskType-button")).click();
			String activityName = "//select[@id='tsklstSPkTargetTaskType']//option[@value='" + activityType + "']";
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();",
					driver.findElement(By.xpath(activityName)));
			driver.findElement(By.xpath(activityName)).click();
			String processActionButton = "//a[@id='processActionButton']";
			Webdriver_waitToClick(processActionButton);
			driver.findElement(By.xpath("//a[@id='processActionButton']")).click();
			String addressLabel = "//h2/span[@id='m1PkAdrAddress-lbl']";
			Webdriver_waitToClick(addressLabel);

			// Entering Address and City Name
			driver.findElement(By.xpath("//input[@id='m1PkAdrAddress']")).sendKeys("1244 Oxford Ave NW");
			driver.findElement(By.xpath("//input[@id='m1PkAdrCity']")).sendKeys("Canton");

			// Selecting Country
			driver.findElement(By.xpath("//div[@id='m1PkAdrCountry-button']")).click();
			String countryName = "//div[@id='m1PkAdrCountry-button']//option[text()='United States of America']";
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();",
					driver.findElement(By.xpath(countryName)));
			driver.findElement(By.xpath(countryName)).click();

			// Selecting City
			driver.findElement(By.xpath("//div[@id='m1PkAdrState-button']")).click();
			String cityName = "//div[@id='m1PkAdrState-button']//option[text()='Ohio']";
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();",
					driver.findElement(By.xpath(cityName)));
			driver.findElement(By.xpath(cityName)).click();

			driver.findElement(By.xpath("//a[@id='m1PkAdrOKBtn']")).click();

			String addButton = "//a[@id='m1PkActBtnAdd']";
			Webdriver_waitToClick(addButton);

			// Selecting KeepWithCrew
			driver.findElement(By.xpath("m1PkActPickupStatus-button")).click();
			String workStatus = "//div[@id='m1PkActPickupStatus-button']//option[text()='Work It']";
			Webdriver_waitToClick(workStatus);
			driver.findElement(By.xpath(workStatus)).click();
			driver.findElement(By.xpath(addButton)).click();

			Webdriver_waitToClick("//a[@id='pageMenuButton']");

		} catch (Exception e) {
			fail(e.getMessage());
			InfoDescription = e.getMessage();
			logComments(InfoDescription, CONST_FAILED);
			return "N";
		}
		return "N";
	}

	public String HybridMCP_addActivityAndSelectActivity(String activityType) throws Exception {
		try {
			driver.findElement(MobileBy.id("pageMenuButton")).click();
			Thread.sleep(1000);
			driver.findElement(By.xpath("//span[text()='Add Activity']")).click();
			Thread.sleep(2000);
			HybridMCPM2_scrollAndSelectDropdown(activityType);
			WebDriverWait wait = new WebDriverWait(driver, 20);
			wait.until(ExpectedConditions.elementToBeClickable(By.id("tsklstSPkTargetTaskType-button")));
			driver.findElement(By.id("tsklstSPkTargetTaskType-button")).click();
			String activityName = "//select[@id='tsklstSPkTargetTaskType']//option[@value='" + activityType + "']";
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();",
					driver.findElement(By.xpath(activityName)));
			driver.findElement(By.xpath(activityName)).click();
			String processActionButton = "//a[@id='processActionButton']";
			Webdriver_waitToClick(processActionButton);
			driver.findElement(By.xpath("//a[@id='processActionButton']")).click();
		} catch (Exception e) {
			fail(e.getMessage());
			InfoDescription = e.getMessage();
			logComments(InfoDescription, CONST_FAILED);
			return "N";
		}
		return "N";
	}
	
	public String HybridMCPM2_addActivityAndSelectActivity(String activityType) throws Exception {
		try {
			driver.findElement(MobileBy.id("pageMenuButton")).click();
			Thread.sleep(1000);
			driver.findElement(By.xpath("//span[text()='Add Activity']")).click();
			Thread.sleep(2000);
			WebDriverWait wait = new WebDriverWait(driver, 20);
			wait.until(ExpectedConditions.elementToBeClickable(By.id("tsklstSPkTargetTaskType-button")));
			driver.findElement(By.id("tsklstSPkTargetTaskType-button")).click();
			String activityName = "//select[@id='tsklstSPkTargetTaskType']//option[@value='" + activityType + "']";
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();",
					driver.findElement(By.xpath(activityName)));
			driver.findElement(By.xpath(activityName)).click();
			String processActionButton = "//a[@id='processActionButton']";
			Webdriver_waitToClick(processActionButton);
			driver.findElement(By.xpath("//a[@id='processActionButton']")).click();
		} catch (Exception e) {
			fail(e.getMessage());
			InfoDescription = e.getMessage();
			logComments(InfoDescription, CONST_FAILED);
			return "N";
		}
		return "N";
	}

	public String HybridMCP_fillAddress(String Address, String city, String country, String state) throws Exception {
		try {
			String addressLabel = "//h2/span[@id='m1PkAdrAddress-lbl']";
			Webdriver_waitToClick(addressLabel);

			// Entering Address and City Name
			driver.findElement(By.xpath("//input[@id='m1PkAdrAddress']")).sendKeys(Address);
			driver.findElement(By.xpath("//input[@id='m1PkAdrCity']")).sendKeys(city);
            try {
			// Selecting Country
			driver.findElement(By.xpath("//div[@id='m1PkAdrCountry-button']")).click();
			String countryName = "//div[@id='m1PkAdrCountry-button']//option[text()='" + country + "']";
			HybridMCP_selectDropdown(countryName);
            }catch(Exception e) {
            	
            }

			// ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();",
			// driver.findElement(By.xpath(countryName)));
			// driver.findElement(By.xpath(countryName)).click();

			// Selecting state
			driver.findElement(By.xpath("//div[@id='m1PkAdrState-button']")).click();
			String stateName = "//div[@id='m1PkAdrState-button']//option[text()='" + state + "']";
			HybridMCP_selectDropdown(stateName);
			
			 * ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();",
			 * driver.findElement(By.xpath(cityName)));
			 * driver.findElement(By.xpath(cityName)).click();
			 
		} catch (Exception e) {
			fail(e.getMessage());
			InfoDescription = e.getMessage();
			logComments(InfoDescription, CONST_FAILED);
			return "N";
		}
		return "N";
	}
	
	public String HybridMCPM2_fillAddress(String Address, String city, String country, String state) throws Exception {
		try {
			String addressLabel = "//h2/span[@id='m2SPQAddress-lbl']";
			Webdriver_waitToClick(addressLabel);

			// Entering Address and City Name
			driver.findElement(By.xpath("//input[@id='m2SPQAddress']")).sendKeys(Address);
			driver.findElement(By.xpath("//input[@id='m2SPQCity']")).sendKeys(city);
			driver.findElement(By.xpath("//a[@id='m2SPQOKBtn']")).click();
            String override = "//li[@id='m2SPQOverrideVerifyDiv']//a[text()='Overridden']";
            Webdriver_waitToClick(override);
            driver.findElement(By.xpath(override)).click();
            Thread.sleep(1000);
            driver.findElement(By.xpath("//a[@id='m2SPQOKBtn']")).click();
			// Selecting City
            String stateDropdown = "//div[@id='m1PkAdrState-button']//select//option";
            Webdriver_waitToClick(stateDropdown);
			driver.findElement(By.xpath(stateDropdown)).click();
			String stateName = "//*[text()='" + state + "']";
			//String cityName = "//*[text()='\" + activityType + \"']";
			HybridMCP_selectDropdown(stateName);
		} catch (Exception e) {
			fail(e.getMessage());
			InfoDescription = e.getMessage();
			logComments(InfoDescription, CONST_FAILED);
			return "N";
		}
		return "N";
	}

	public String HybridMCP_addUnRelatedPickUpActivity(String activityType, String address, String city, String country,
			String state, String workStatus) throws Exception {
		try {
			WebDriverWait wait = new WebDriverWait(driver, 240);
			wait.until(ExpectedConditions.elementToBeClickable(By.id("pageMenuButton")));
			HybridMCP_addActivityAndSelectActivity(activityType);
			HybridMCP_fillAddress(address, city, country, state);
			Webdriver_waitToClick("//a[@id='m1PkAdrOKBtn']");
			driver.findElement(By.xpath("//a[@id='m1PkAdrOKBtn']")).click();
			String addButton = "//a[@id='m1PkActBtnAdd']";
			Webdriver_waitToClick(addButton);
			//Added for testing
			HybridMCP_selectWorkStatus("Work It");
			Webdriver_waitToClick(addButton);
			driver.findElement(By.xpath(addButton)).click();
			//Webdriver_waitToClick(addButton);
			Webdriver_waitToClick("//a[@id='pageMenuButton']");
			Thread.sleep(5000);			
			//Adding to test attachments
			//HybridMCP_addAttachment();
		} catch (Exception e) {
			fail(e.getMessage());
			InfoDescription = e.getMessage();
			logComments(InfoDescription, CONST_FAILED);
			return "N";
		}
		return "N";
	}
	
	public String HybridMCPM2_addUnRelatedPickUpActivity(String activityType, String address, String city, String country,
			String state, String workStatus) throws Exception {
		try {
			WebDriverWait wait = new WebDriverWait(driver, 240);
			wait.until(ExpectedConditions.elementToBeClickable(By.id("pageMenuButton")));
			HybridMCP_addActivityAndSelectActivity(activityType);
			HybridMCPM2_fillAddress(address, city, country, state);
			Thread.sleep(1000);
			driver.findElement(By.xpath("//a[@id='m1PkAdrOKBtn']")).click();
			String addButton = "//a[@id='m2PkActBtnAddUR']";
			Thread.sleep(2000);
			Webdriver_waitToClick(addButton);
			//Added for testing
			HybridMCPM2_selectWorkStatus("Work It");
			//HybridMCP_selectWorkStatus("Work It");
			driver.findElement(By.xpath(addButton)).click();
			Webdriver_waitToClick("//a[@id='pageMenuButton']");
			Thread.sleep(5000);	
		} catch (Exception e) {
			fail(e.getMessage());
			InfoDescription = e.getMessage();
			logComments(InfoDescription, CONST_FAILED);
			return "N";
		}
		return "N";
	}

	public String HybridMCP_startM2ConnectSPActivity(String activity_task_id, String MaxTimeToWaitInMilliSeconds)
			throws Exception {
		try {
			String headerText = clickByAssignmentID(activity_task_id);
			info("Header Text: " + headerText);

			WebElement enrouteButton = driver.findElement(By.xpath("//div/a[@role='button']//span[text()='En Route']"));
			
			 * WebElement enrouteButton = (new WebDriverWait(driver, 60))
			 * .until(ExpectedConditions.presenceOfElementLocated(By.
			 * xpath("//div/a[@role='button']//span[text()='En Route']")));
			 
			Thread.sleep(3500);
			enrouteButton.click();

			WebElement startButton = driver.findElement(By.xpath("//div/a[@role='button']//span[text()='Start']"));
			
			 * WebElement startButton = (new WebDriverWait(driver, 60))
			 * .until(ExpectedConditions.presenceOfElementLocated(By.xpath(
			 * "//div/a[@role='button']//span[text()='Start']")));
			 
			Thread.sleep(4000);
			startButton.click();

			Thread.sleep(7000);
			
			 * WebElement completionTab = (new WebDriverWait(driver, 60))
			 * .until(ExpectedConditions.presenceOfElementLocated(By.xpath(
			 * "//span[@id='m1CommonCmpl-lbl']"))); Thread.sleep(2000);
			 * if(driver.findElements(By.
			 * xpath("//span[@id='m1CommonCmpl-lbl']/../span[contains(text(),'click to expand contents')]"
			 * )).size() != 0){ completionTab.click(); }
			 * 
			 * Thread.sleep(2500); /* WebElement dropDownSelect =
			 * driver.findElement(By.id("m1CCCustomerContactType")); Select mySelect= new
			 * Select(dropDownSelect); mySelect.selectByValue("WEB");
			 * 
			 * Thread.sleep(1000);
			 * 
			 * driver.findElement(By.xpath("//textarea[@id='m1CCCustomerContactComments']"))
			 * .sendKeys("Contact comments of this Activity."); Thread.sleep(1000);
			 * driver.findElement(By.xpath("//textarea[@id='m1CCToDoMessage']")).
			 * sendKeys("Review is not required for this Sample Activity.");
			 * Thread.sleep(1000);
			 * driver.findElement(By.xpath("//textarea[@id='m1CCComments']")).
			 * sendKeys("Sample Comment for this Activity.");
			 * 
			 * Thread.sleep(1500);
			 
		} catch (Exception e) {
			fail(e.getMessage());
			InfoDescription = e.getMessage();
			logComments(InfoDescription, CONST_FAILED);
			return "N";
		}
		return "N";
	}

	public String HybridMCP_completeM2ConnectSPActivity() throws Exception {
		try {

			Thread.sleep(5000);
			WebElement completeButton = driver
					.findElement(By.xpath("//div/a[@role='button']//span[text()='Complete']"));
			
			 * WebElement completeButton = (new WebDriverWait(driver, 60))
			 * .until(ExpectedConditions.presenceOfElementLocated(By.xpath(
			 * "//div/a[@role='button']//span[text()='Complete']")));
			 
			Thread.sleep(2000);
			completeButton.click();
		} catch (Exception e) {
			fail(e.getMessage());
			InfoDescription = e.getMessage();
			logComments(InfoDescription, CONST_FAILED);
			return "N";
		}
		return "N";
	}

	public String HybridMCP_endShift() throws Exception {
		try {
			Thread.sleep(3000);

			WebElement completedTab = driver.findElement(By.xpath("//a[@id='completedTab-label']"));
			
			 * WebElement completedTab = (new WebDriverWait(driver, 100))
			 * .until(ExpectedConditions.presenceOfElementLocated(By.xpath(
			 * "//a[@id='completedTab-label']")));
			 
			Thread.sleep(1000);
			completedTab.click();

			Thread.sleep(3000);

			driver.findElement(By.xpath("//a[@id='pageMenuButton']")).click();
			
			 * (new WebDriverWait(driver, 100))
			 * .until(ExpectedConditions.presenceOfElementLocated(By.xpath(
			 * "//a[@id='pageMenuButton']"))).click();
			 

			Thread.sleep(3000);
			driver.findElement(By.xpath("//li/a/span[text()='End of Shift']")).click();

			Thread.sleep(3000);

			WebElement completeButton = driver
					.findElement(By.xpath("//div/a[@role='button']//span[text()='Complete']"));

			
			 * WebElement completeButton = (new WebDriverWait(driver, 60))
			 * .until(ExpectedConditions.presenceOfElementLocated(By.xpath(
			 * "//div/a[@role='button']//span[text()='Complete']")));
			 
			Thread.sleep(1000);
			driver.findElement(By.xpath("//div/a[text()='Yes']")).click();
			completeButton.click();

			// (new WebDriverWait(driver,
			// 100)).until(ExpectedConditions.presenceOfElementLocated(By.id("alertPopup-screen")));
			Thread.sleep(10000);
		} catch (Exception e) {
			fail(e.getMessage());
			InfoDescription = e.getMessage();
			logComments(InfoDescription, CONST_FAILED);
			return "N";
		}
		return "N";
	}

	public String HybridMCP_closeRemoteDriver() throws Exception {
		try {
			info("Shutting down the driver instance.");
			
			 * for (String window : driver.getWindowHandles()) { driver.close(); }
			 
			driver.quit();
			// driver.close(); // This will stop and destroy the driver instance
			info("Remote Driver is closed.");
		} catch (Exception e) {
			fail(e.getMessage());
			InfoDescription = e.getMessage();
			logComments(InfoDescription, CONST_FAILED);
			return "N";
		}
		return "N";
	}

	// -------------------------------------------------------------------------------------------
	public boolean HybridMCP_clearSanityEmailReport() throws Exception {
		// To clear the previous run test results
		return true;
	}

	// Need to change this
	public boolean HybridMCP_sendSanityEmailReport() throws Exception {
		Properties prop = new Properties();
		InputStream input = null;

		try {

			input = new FileInputStream(getVariables.get("gStrRepositoryPath") + "\\Mobile\\" + "sanity.properties");

			// load a properties file
			prop.load(input);

			StringBuilder report = new StringBuilder(
					"<html><body lang=EN-US link=blue vlink=purple><u>Test Configurations</u>:<br><br>");
			StringBuilder report_warning = new StringBuilder("<br><br><u>Warnings</u>:<br><br><ul>");
			Boolean warning = false; // This will hide the Warning DIV

			report.append("<li><b>Environment</b>: " + "https://slc09kty.us.oracle.com:7300/ouaf" + "</li>");
			report.append("<li><b>Login User</b>: " + "SYSUSER" + "</li>");
			report.append("<li><b>Chrome URL</b>: "
					+ "https://slc09kty.us.oracle.com:7300/ouaf/mobility/rest/www/index.html" + "</li>");
			report.append("<li><b>Mobility URL</b>: " + "https://slc09kty.us.oracle.com:7300/ouaf/mobility/main"
					+ "</li></ul><br><br>");

			report.append(
					"<u>Sanity Test Results</u>:<br><br><table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0 style='font-size:9.5pt;font-family:\"Verdana\",\"sans-serif\";margin-left:-1.15pt;border-collapse:collapse'><tr style='height:15.0pt'><td nowrap valign=bottom style="
							+ "'border:solid windowtext 1.0pt;background:black;padding:0in 5.4pt 0in 5.4pt;height:15.0pt'><p class=MsoNormal><span style='color:white'>&nbsp;<o:p></o:p></span></p></td><td nowrap valign=bottom style='border:solid windowtext 1.0pt;border-left:"
							+ "none;background:black;padding:0in 5.4pt 0in 5.4pt;height:15.0pt'><p class=MsoNormal align=center style='text-align:center'>"
							+ "<span style='color:yellow'>Crew ID<o:p></o:p></span></p></td><td nowrap valign=bottom style='border:solid windowtext 1.0pt;"
							+ "border-left:none;background:black;padding:0in 5.4pt 0in 5.4pt;height:15.0pt'><p class=MsoNormal align=center style='text-align:center'>"
							+ "<span style='color:yellow'>Crew-Shift ID<o:p></o:p></span></p></td><td nowrap valign=bottom style='border:solid windowtext"
							+ " 1.0pt;border-left:none;background:black;padding:0in 5.4pt 0in 5.4pt;height:15.0pt'><p class=MsoNormal align=center style"
							+ "='text-align:center'><span style='color:yellow'>M1-Activity ID<o:p></o:p></span></p></td><td nowrap valign=bottom style="
							+ "'border:solid windowtext 1.0pt;border-left:none;background:black;padding:0in 5.4pt 0in 5.4pt;height:15.0pt'><p class="
							+ "MsoNormal align=center style='text-align:center'><span style='color:yellow'>M2-Activity ID<o:p></o:p></span></p></td><td nowrap"
							+ " valign=bottom style='border:solid windowtext 1.0pt;border-left:none;background:black;padding:0in 5.4pt 0in 5.4pt;height:15.0pt'>"
							+ "<p class=MsoNormal align=center style='text-align:center'><span style='color:yellow'>Break ID<o:p></o:p></span></p></td>"
							+ "<td nowrap valign=bottom style='border:solid windowtext 1.0pt;border-left:none;background:black;padding:0in 5.4pt 0in 5.4pt;"
							+ "height:15.0pt'><p class=MsoNormal align=center style='text-align:center'><span style='color:yellow'>NPT ID<o:p></o:p></span></p>"
							+ "</td><td nowrap valign=bottom style='border:solid windowtext 1.0pt;border-left:none;background:black;padding:0in 5.4pt 0in 5.4pt;"
							+ "height:15.0pt'><p class=MsoNormal align=center style='text-align:center'><span style='color:yellow'>POU ID<o:p></o:p></span></p>"
							+ "</td></tr>");

			String MDTName = "Non"; // SET MDT name
			report.append(addSanityReportRow("Non", prop.getProperty(MDTName + "_Crew", "<b>Missing</b>"),
					prop.getProperty(MDTName + "_CrewShift", "<b>Missing</b>"),
					prop.getProperty(MDTName + "_Activity1", "<b>Missing</b>"),
					prop.getProperty(MDTName + "_Activity2", "<b>Missing</b>"),
					prop.getProperty(MDTName + "_Break", "<b>Missing</b>"),
					prop.getProperty(MDTName + "_NPT", "<b>Missing</b>"),
					prop.getProperty(MDTName + "_POU", "<b>Missing</b>")));

			MDTName = "Non"; // SET MDT name

			report.append(addSanityReportRow("Chrome", prop.getProperty(MDTName + "_Crew", "<b>Missing</b>"),
					prop.getProperty(MDTName + "_CrewShift", "<b>Missing</b>"),
					prop.getProperty(MDTName + "_Activity1", "<b>Missing</b>"),
					prop.getProperty(MDTName + "_Activity2", "<b>Missing</b>"),
					prop.getProperty(MDTName + "_Break", "<b>Missing</b>"),
					prop.getProperty(MDTName + "_NPT", "<b>Missing</b>"),
					prop.getProperty(MDTName + "_POU", "<b>Missing</b>")));

			MDTName = "Non"; // SET MDT name
			report.append(addSanityReportRow("Android", prop.getProperty(MDTName + "_Crew", "<b>Missing</b>"),
					prop.getProperty(MDTName + "_CrewShift", "<b>Missing</b>"),
					prop.getProperty(MDTName + "_Activity1", "<b>Missing</b>"),
					prop.getProperty(MDTName + "_Activity2", "<b>Missing</b>"),
					prop.getProperty(MDTName + "_Break", "<b>Missing</b>"),
					prop.getProperty(MDTName + "_NPT", "<b>Missing</b>"),
					prop.getProperty(MDTName + "_POU", "<b>Missing</b>")));

			MDTName = "Non"; // SET MDT name
			report.append(addSanityReportRow("IOS", prop.getProperty(MDTName + "_Crew", "<b>Missing</b>"),
					prop.getProperty(MDTName + "_CrewShift", "<b>Missing</b>"),
					prop.getProperty(MDTName + "_Activity1", "<b>Missing</b>"),
					prop.getProperty(MDTName + "_Activity2", "<b>Missing</b>"),
					prop.getProperty(MDTName + "_Break", "<b>Missing</b>"),
					prop.getProperty(MDTName + "_NPT", "<b>Missing</b>"),
					prop.getProperty(MDTName + "_POU", "<b>Missing</b>")));

			MDTName = "Windows"; // SET MDT name
			if (prop.getProperty(MDTName + "_Crew", "Missing").trim().equals("Missing")) {
				warning = true;
				report_warning.append("<li>Windows-MDT flow is missing or not Executed.</li>");
				report_warning.append("<li>M2-Activity is missing in all flows.</li>");
			} else {
				report.append(addSanityReportRow("Windows", prop.getProperty(MDTName + "_Crew", "<b>Missing</b>"),
						prop.getProperty(MDTName + "_CrewShift", "<b>Missing</b>"),
						prop.getProperty(MDTName + "_Activity1", "<b>Missing</b>"),
						prop.getProperty(MDTName + "_Activity2", "<b>Missing</b>"),
						prop.getProperty(MDTName + "_Break", "<b>Missing</b>"),
						prop.getProperty(MDTName + "_NPT", "<b>Missing</b>"),
						prop.getProperty(MDTName + "_POU", "<b>Missing</b>")));
			}

			// ------------------------
			report.append("</table>");
			if (warning == true) {
				report.append(report_warning.toString() + "</ul>");
			}
			report.append(
					"<br><br><span style='font-size:7.5pt;font-family:\"Verdana\",\"sans-serif\";color:#6D6968'>This email message was automatically generated by "
							+ "Open-Script. If you think you are getting this by mistake then contact xxxx@oracle.com</span><br><span style='font-size:7.5pt;font-family:\"Verdana\","
							+ "\"sans-serif\";color:#4B7D42'>Oracle is committed to developing practices and products that help protect the environment</span></body></html>");

			wSCOMMONLIB.sendMail("nilesh.k.singh@oracle.com", "Sanity Test Report", report.toString(),
					"noreply@oracle.com", "internal-mail-router.oracle.com", "25");

		} catch (IOException io) {
			io.printStackTrace();
		} finally {
			if (input != null) {
				try {
					input.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}

		}

		return true; // success
	}

	private void logComments(String aStrInfo, String aStrStatus) throws Exception {

		try {
			// getScript("WSCOMMONLIB").callFunction("logComments",getVariables.get("gStrOutputFileName"),aStrInfo,aStrStatus);
			wSCOMMONLIB.logComments(getVariables.get("gStrOutputFileName"), aStrInfo);
		} catch (Exception e) {
			info("Exception" + e.getMessage());
		}

	}

	public String clickByAssignmentID(String current_task_id) throws Exception {
		int xpath_index = getIndexbyTaskId(current_task_id, 10); // Waiting Time = 10 seconds
		String headerText = "";
		if (xpath_index == -1) {
			info("Task Id:" + current_task_id + " not found. Waited for 10 seconds.");
		} else {
			// Waiting for xpath_index'th Task to dispatched

			WebElement element1 = driver.findElement(By.xpath("//ul[@id='tasklistview']/li[" + xpath_index + "]"));
			
			 * (new WebDriverWait(driver, 100))
			 * .until(ExpectedConditions.presenceOfElementLocated(By.xpath(
			 * "//ul[@id='tasklistview']/li["+xpath_index+"]")));
			 
			Thread.sleep(4000); // Stale Exception: 4 Sec wait

			info("This Task is located in " + xpath_index + " index");
			WebElement selectedTask = driver.findElement(By.xpath("//ul[@id='tasklistview']/li[" + xpath_index + "]"));
			if (selectedTask.isDisplayed()) {
				info("The selected task is Visible. Will Try to Click it..");
				selectedTask.click();
			} else {
				info("The selected task is Not Visible.");
			}

			// Click was not working in IOS Simulator
			// IOS TAP Handler
			if (DEVICE_TYPE.equals("IOS")) {
				info("The selected task is Not Clickable. Trying to get coordinates of the webelement and TAP at that coordinate.");
				Point point = selectedTask.getLocation();
				Dimension size = selectedTask.getSize();

				int elementCenterX = point.getX() + Math.round(size.getWidth() / 2);
				int elementCenterY = point.getY() + Math.round(size.getHeight() / 2);
				info("X-Coordinate: " + elementCenterX + " , Y-Coordinate: " + elementCenterY);

				String originalContext = ((AppiumDriver<MobileElement>) driver).getContext();

				info("Switching to NATIVE View.");
				((AppiumDriver<MobileElement>) driver).context("NATIVE_APP");
				Thread.sleep(1000);
				// Nagesh - error in the tap -- ((AppiumDriver<MobileElement>) driver).tap(1,
				// elementCenterX , elementCenterY , 1);

				Thread.sleep(2500);
				// ((AppiumDriver<MobileElement>) driver).findElement(By.name("Open")).click();

				info("Switching to WEB View.");
				((AppiumDriver<MobileElement>) driver).context(originalContext);

			} else {
				Thread.sleep(3000);

				WebElement element2 = driver.findElement(By.xpath("//div[@id='allHeaders']/h1//span"));
				
				 * (new WebDriverWait(driver, 60))
				 * .until(ExpectedConditions.presenceOfElementLocated(By.xpath(
				 * "//div[@id='allHeaders']/h1//span")));
				 
				Thread.sleep(2000);
				headerText = driver.findElement(By.xpath("//div[@id='allHeaders']/h1//span")).getText().trim();
			}

			
			 * //Waiting for xpath_index'th Task to dispatched (new WebDriverWait(driver,
			 * 100)) .until(ExpectedConditions.presenceOfElementLocated(By.xpath(
			 * "//ul[@id='tasklistview']/li["+xpath_index+"]"))); Thread.sleep(4000);
			 * //Stale Exception: 4 Sec wait //Click was not working in IOS Simulator
			 * info("This Task is located in "+ xpath_index + " index"); WebElement
			 * selectedTask =
			 * driver.findElement(By.xpath("//ul[@id='tasklistview']/li["+xpath_index+"]"));
			 * if(selectedTask.isDisplayed()){
			 * info("The selected task is Visible. Will Try to Click it..");
			 * selectedTask.click(); } else{ info("The selected task is Not Visible."); }
			 * 
			 * 
			 * Thread.sleep(3000); (new WebDriverWait(driver, 60))
			 * .until(ExpectedConditions.presenceOfElementLocated(By.xpath(
			 * "//div[@id='allHeaders']/h1//span"))); Thread.sleep(2000); headerText =
			 * driver.findElement(By.xpath("//div[@id='allHeaders']/h1//span")).getText().
			 * trim();
			 * 
			 * //IOS TAP Handler if(headerText.equals("Tasks")){
			 * info("The selected task is Not Visible. Trying to get coordinates of the webelement and TAP at that coordinate."
			 * ); Point point = selectedTask.getLocation(); Dimension size =
			 * selectedTask.getSize();
			 * 
			 * int elementCenterX = point.getX() + Math.round(size.getWidth() / 2); int
			 * elementCenterY = point.getY() + Math.round(size.getHeight() / 2);
			 * info("X-Coordinate: "+elementCenterX + " , Y-Coordinate: "+elementCenterY);
			 * 
			 * String originalContext = ((AppiumDriver<MobileElement>) driver).getContext();
			 * 
			 * 
			 * 
			 * info("Switching to NATIVE View."); ((AppiumDriver<MobileElement>)
			 * driver).context("NATIVE_APP"); Thread.sleep(1000);
			 * ((AppiumDriver<MobileElement>) driver).tap(1, elementCenterX , elementCenterY
			 * , 1);
			 * 
			 * Thread.sleep(2500); //((AppiumDriver<MobileElement>)
			 * driver).findElement(By.name("Open")).click();
			 * 
			 * info("Switching to WEB View."); ((AppiumDriver<MobileElement>)
			 * driver).context(originalContext);
			 * 
			 * 
			 * }
			 
		}
		return headerText;
	}

	
	 * This method will find the Task index based on taskId
	 
	int getIndexbyTaskId(String taskId, int wait_seconds) throws Exception {

		int xpath_index = -1; // not found

		JavascriptExecutor js = (JavascriptExecutor) driver;
		for (int j = 0; j < wait_seconds; j++) {
			if (xpath_index == -1) {
				Thread.sleep(3000); // wait for 1 seconds
				long count = (Long) js.executeScript("return ouml.App.getPageContext().viewModel.taskList().length;");
				info("------------- Javascript Response = " + count);
				for (int i = 0; i < count; i++) {
					if (js.executeScript("return ouml.App.getPageContext().viewModel.taskList()[" + i + "].taskId;")
							.toString().trim().equals(taskId)) {
						xpath_index = i + 1;
					}
				}
			}
		}
		return xpath_index;
	}

	public String IosMCP_startRemoteDriver() throws Exception {
		try {
			String mwmAppPackageName = "com.oraclecorp.internal.mwm.runtime";
			String mwmAppActivityName = "com.oraclecorp.internal.mwm.runtime.HybridRuntimeActivity";

			DEVICE_TYPE = "IOS";
			info("DEVICE-TYPE is set for iOS.");

			String iosVersion = getVariables.get("gStrIOSVersion"); // 9.1
			String deviceName = getVariables.get("gStrIOSDeviceName"); // emulator
			String deviceUID = getVariables.get("gStrIOSDeviceUID"); // For Device and emulator(optional)
			String iosBuildDirectory = getVariables.get("gStrIosBuildPath");
			String iosNodeUrl = getVariables.get("gStrIosMCPRemoteNodeURL");

			info("IOS Latest Build directory: " + iosBuildDirectory);

			DesiredCapabilities capabilities = new DesiredCapabilities();
			capabilities.setCapability("appium-version", "1.6.4");
			capabilities.setCapability("platformName", "ios");
			capabilities.setCapability("platformVersion", "10.3.3");
			capabilities.setCapability("deviceName", "iPad");
			capabilities.setCapability(MobileCapabilityType.UDID, "33ad17f071d36d191d0a6e6b102b8ed3e7783c58");
			capabilities.setCapability("xcodeConfigFile",
					"/Users/mcpdev/Library/Developer/Xcode/DerivedData/WebDriverAgent-brdadhpuduowllgivnnvuygpwhzy/Build/Products/Debug-iphoneos/IntegrationApp.app");
			// capabilities.setCapability(IOSMobileCapabilityType.LAUNCH_TIMEOUT,50000);
			// capabilities.setCapability("xcodeConfigFile","/usr/local/lib/node_modules/appium/node_modules/appium-xcuitest-driver/WebDriverAgent/Config.xcconfig");
			capabilities.setCapability("showXcodeLog", "true");
			capabilities.setCapability("clearSystemFiles", "true");
			// capabilities.setCapability("xcodeOrgId","AHFF7VTWH7");
			// capabilities.setCapability("xcodeSigningId","iPhone Developer");

			// capabilities.setCapability("app",
			// "/Users/mcpdev/Desktop/Desktop/Nagesh/debug/Oracle_MWM_2301_old.ipa");
			// capabilities.setCapability("app",
			// "/Users/mcpdev/Library/Developer/Xcode/DerivedData/Oracle_MWM-epejpbjecavlxbegwcjxfbdcexom/Build/Products/Debug-iphoneos/Oracle
			// MWM.app");
			capabilities.setCapability("automationName", "XCUITest");
			// capabilities.setCapability("app",
			// "/Users/mcpdev/Library/Developer/Xcode/DerivedData/WebDriverAgent-brdadhpuduowllgivnnvuygpwhzy/Build/Products/Debug-iphonesimulator/IntegrationApp.app");
			capabilities.setCapability("bundleId", "com.oraclecorp.internal.mwm.runtime");
			// capabilities.setCapability("bundleId", "com.oracle.ugbu.mwm.runtime"); --
			// Wrong bundle id
			// capabilities.setCapability("bundleId", "com.facebook.IntegrationAppies");
			// capabilities.setCapability("autoAcceptAlerts", true);

			// capabilities.setCapability("noReset","true");
			// capabilities.setCapability("fullReset","false");
			// capabilities.setCapability("automationName","Appium");

			// capabilities.setCapability("deviceName", deviceName);
			// capabilities.setCapability("automationName", "XCUITest");

			// capabilities.setCapability("bundleId", "com.oracle.ugbu.mwm.runtime");
			// capabilities.setCapability("bundleId", mwmAppPackageName);

			
			 * Old Code - By Nilesh
			 * 
			 * 
			 * DesiredCapabilities capabilities = new DesiredCapabilities();
			 * 
			 * // capabilities.setCapability("noReset","true"); //
			 * capabilities.setCapability("fullReset","false");
			 * capabilities.setCapability("automationName","Appium");
			 * capabilities.setCapability("autoAcceptAlerts", true);
			 * capabilities.setCapability("deviceName", deviceName); //
			 * capabilities.setCapability("automationName", "XCUITest");
			 * 
			 * if(deviceUID!=null) capabilities.setCapability(MobileCapabilityType.UDID,
			 * deviceUID);
			 * 
			 * capabilities.setCapability(CapabilityType.VERSION, iosVersion); //Version for
			 * simulator 9.1 , Version for I-pad is 8.4
			 * capabilities.setCapability(CapabilityType.PLATFORM, "Mac");
			 * capabilities.setCapability(MobileCapabilityType.APP, iosBuildDirectory); //
			 * capabilities.setCapability("bundleId", "com.oracle.ugbu.mwm.runtime");
			 * capabilities.setCapability("bundleId", mwmAppPackageName);
			 

			driver = new IOSDriver<MobileElement>(new URL(iosNodeUrl), capabilities);

			driver.findElement(By.name("Alerts")).click();

			return "N";
		} catch (Exception e) {
			fail(e.getMessage());
			InfoDescription = e.toString();
			logComments(InfoDescription, CONST_FAILED);
			return "N";
		}
	}

	public String ChromeMCP_startRemoteDriver() throws Exception {
		try {

			DEVICE_TYPE = "CHROME";
			info("DEVICE-TYPE is set for CHROME Web-Browser.");

			String mcpURL = getVariables.get("gStrNewMCPURL");
			String remoteDriverURL = getVariables.get("gStrChromeMCPRemoteNodeURL");
			String osPlatform = getVariables.get("gStrChromeOSPlatform");
			String chromeVersion = getVariables.get("gStrChromeBrowserVersion");

			ChromeOptions options = new ChromeOptions();
			options.addArguments("--start-maximized");
			options.addArguments("--unlimited-storage");

			info("Creating capabilities for Chrome browser: VERSION(" + chromeVersion + "), PLATFORM(" + osPlatform
					+ ")");
			DesiredCapabilities capabilities = DesiredCapabilities.chrome();
			capabilities.setCapability(ChromeOptions.CAPABILITY, options);
			capabilities.setCapability("version", chromeVersion);
			capabilities.setCapability("platform", osPlatform);
			capabilities.setCapability("platformName", "Android");
			capabilities.setCapability("deviceName", "Chrome");
			info("Connecting to the Remote Node URL: " + remoteDriverURL);
			// driver = new RemoteWebDriver(new URL("http://10.178.147.195:5555/wd/hub"),
			// capabilities); //Demo
			driver = new RemoteWebDriver(new URL(remoteDriverURL), capabilities);
			System.out.println("Invoke Chrome Browser");
			ChromeOptions options = new ChromeOptions();
	        options.addArguments("start-maximized");
			System.setProperty(getVariables.get("UI_systemProperty"), getVariables.get("UI_webdriver"));
	        driver = new ChromeDriver();
			info("Connection got successfully established");
			driver.manage().window().maximize();
			info("Browser Window is Maximized.");
			driver.get(mcpURL);
			driver.navigate().refresh();
			info("Connecting to the Chrome MCP URL:" + mcpURL);
			return "N";

			// Original Code below:

			
			 * DEVICE_TYPE = "CHROME"; info("DEVICE-TYPE is set for CHROME Web-Browser.");
			 * 
			 * String mcpURL=getVariables.get("gStrNewMCPURL"); String
			 * remoteDriverURL=getVariables.get("gStrChromeMCPRemoteNodeURL"); String
			 * osPlatform=getVariables.get("gStrChromeOSPlatform"); String
			 * chromeVersion=getVariables.get("gStrChromeBrowserVersion");
			 * 
			 * 
			 * ChromeOptions options = new ChromeOptions();
			 * options.addArguments("--start-maximized");
			 * 
			 * info("Creating capabilities for Chrome browser: VERSION("
			 * +chromeVersion+"), PLATFORM("+osPlatform+")"); DesiredCapabilities
			 * capabilities = DesiredCapabilities.chrome();
			 * capabilities.setCapability(ChromeOptions.CAPABILITY, options);
			 * capabilities.setCapability("version", chromeVersion);
			 * capabilities.setCapability("platform", osPlatform);
			 * capabilities.setCapability("platformName", "Android");
			 * capabilities.setCapability("deviceName", "Chrome");
			 * info("Connecting to the Remote Node URL: "+remoteDriverURL); // driver = new
			 * RemoteWebDriver(new URL("http://10.178.147.195:5555/wd/hub"), capabilities);
			 * //Demo driver = new RemoteWebDriver(new URL(remoteDriverURL), capabilities);
			 * info("Connection got successfully established");
			 * driver.manage().window().maximize(); info("Browser Window is Maximized.");
			 * driver.get(mcpURL); info("Connecting to the Chrome MCP URL:" + mcpURL);
			 * return "N";
			 } catch (Exception e) {
			fail(e.getMessage());
			InfoDescription = e.toString();
			logComments(InfoDescription, CONST_FAILED);
			return "N";
		}
	}

	
	 * public String WindowsMCP_startRemoteDriver() throws Exception { // Windows-10
	 * MCP is not working currently try { // String
	 * mwpAppPackageFamiliyName="com.oraclecorp.internal.mwm.runtime_h35559jr9hy9m";
	 * DEVICE_TYPE = "WINDOWS"; info("DEVICE-TYPE is set for WINDOWS-10.");
	 * 
	 * String remoteDriverURL=getVariables.get("gStrWindowsMCPRemoteNodeURL"); URL u
	 * = new URL(remoteDriverURL);
	 * 
	 * DesiredCapabilities capabilities = new DesiredCapabilities();
	 * capabilities.setCapability("app",
	 * "Microsoft.WindowsCalculator_8wekyb3d8bbwe!App"); CalculatorSession = new
	 * WindowsDriver(u, capabilities);
	 * CalculatorSession.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
	 * 
	 * CalculatorResult =
	 * CalculatorSession.findElementByAccessibilityId("CalculatorResults");
	 * 
	 * 
	 * return "N";
	 * 
	 * // String
	 * mwpAppPackageFamiliyName="com.oraclecorp.internal.mwm.runtime_h35559jr9hy9m";
	 * DEVICE_TYPE = "WINDOWS"; info("DEVICE-TYPE is set for WINDOWS-10.");
	 * 
	 * String remoteDriverURL=getVariables.get("gStrWindowsMCPRemoteNodeURL");
	 * 
	 * DesiredCapabilities appCapabilities = new DesiredCapabilities();
	 * appCapabilities.setCapability("app",
	 * "Microsoft.WindowsCalculator_8wekyb3d8bbwe!App");
	 * appCapabilities.setCapability("platform", "Windows");
	 * 
	 * try { URL u = new URL(remoteDriverURL); CalculatorSession = new
	 * RemoteWebDriver(u, appCapabilities);
	 * 
	 * WebElement we = CalculatorSession.findElementByName("Five"); if (we != null){
	 * we.click(); } } catch (MalformedURLException mfe) { } return "N"; } catch
	 * (Exception e) { fail(e.getMessage()); InfoDescription = e.toString();
	 * logComments( InfoDescription, CONST_FAILED); return "N"; } }
	 

	public String WindowsMCP_feasibilityTest() throws Exception {
		// This will launch a native calculator app
		try {

			return "N";
		} catch (Exception e) {
			fail(e.getMessage());
			InfoDescription = e.toString();
			logComments(InfoDescription, CONST_FAILED);
			return "N";
		}
	}

	List<String> getFilesByExtension(String directory, String extension) {
		List<String> buildFiles = new ArrayList<String>();
		File dir = new File(directory);
		for (File file : dir.listFiles()) {
			if (file.getName().endsWith((extension.trim()))) {
				buildFiles.add(file.getName());
			}
		}
		return buildFiles;
	}

	
	 * This method will write the variables in the properties file in "Mobile"
	 * folder
	 
	public boolean setSanityVariables(String MDTName, String Crew, String CrewShift, String Activity1, String Activity2,
			String Break, String NPT, String POU) throws Exception {
		Properties prop = new Properties();
		InputStream input = null;
		OutputStream output = null;

		try {

			output = new FileOutputStream(getVariables.get("gStrRepositoryPath") + "\\Mobile\\" + "sanity.properties");
			input = new FileInputStream(getVariables.get("gStrRepositoryPath") + "\\Mobile\\" + "sanity.properties");

			// load a properties file
			prop.load(input);

			// set the properties value
			prop.setProperty(MDTName + "_Crew", Crew);
			prop.setProperty(MDTName + "_CrewShift", CrewShift);
			prop.setProperty(MDTName + "_Activity1", Activity1);
			prop.setProperty(MDTName + "_Activity2", Activity2);
			prop.setProperty(MDTName + "_Break", Break);
			prop.setProperty(MDTName + "_NPT", NPT);
			prop.setProperty(MDTName + "_POU", POU);

			// save properties to project root folder
			prop.store(output, null);

		} catch (IOException io) {
			io.printStackTrace();
		} finally {
			if (output != null) {
				try {
					output.close();
					input.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}

		}

		return true; // success
	}
	
	
	 * This method will write the variables in the properties file in "Mobile"
	 * folder
	 

	
	 * This method will write the variables in the properties file in "Mobile"
	 * folder
	 
	public String addSanityReportRow(String MDTName, String Crew, String CrewShift, String Activity1, String Activity2,
			String Break, String NPT, String POU) throws Exception {
		return ("<tr style='height:15.0pt'><td nowrap valign=bottom style='border:solid windowtext 1.0pt;border-top:none;"
				+ "background:black;padding:0in 5.4pt 0in 5.4pt;height:15.0pt'><p class=MsoNormal><b><span style='color:white'>"
				+ MDTName
				+ "-MDT<o:p></o:p></span></b></p></td><td nowrap valign=bottom style='border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;"
				+ "border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:15.0pt'><p class=MsoNormal><span style='color:black'>"
				+ Crew
				+ "<o:p></o:p></span></p></td><td nowrap valign=bottom style='border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid "
				+ "windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:15.0pt'><p class=MsoNormal><span style='color:black'>"
				+ CrewShift + "<o:p></o:p></span></p></td><td nowrap "
				+ "valign=bottom style='border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in "
				+ "5.4pt;height:15.0pt'><p class=MsoNormal><span style='color:black'>" + Activity1
				+ "<o:p></o:p></span></p></td><td nowrap valign=bottom style="
				+ "'border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:15.0pt'>"
				+ "<p class=MsoNormal><span style='color:black'>" + Activity2
				+ "<o:p></o:p></span></p></td><td nowrap valign=bottom style='border-top:none;"
				+ "border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:15.0pt'><p class=MsoNormal>"
				+ "<span style='color:black'>" + Break
				+ "<o:p></o:p></span></p></td><td nowrap valign=bottom style='border-top:none;border-left:none;border-bottom:solid "
				+ "windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:15.0pt'><p class=MsoNormal><span style='color:black'>"
				+ NPT + "<o:p>"
				+ "</o:p></span></p></td><td nowrap valign=bottom style='border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext"
				+ " 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:15.0pt'><p class=MsoNormal><span style='color:black'>"
				+ POU + "<o:p></o:p></span></p></td></tr>");
	}

	public void finish() throws Exception {
	}
}
*/