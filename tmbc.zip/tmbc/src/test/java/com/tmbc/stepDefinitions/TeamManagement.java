package com.tmbc.stepDefinitions;

import org.openqa.selenium.WebDriver;

import com.tmbc.pages.LoginPage;
import com.tmbc.pages.TeamManagememtPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class TeamManagement {
	public static WebDriver driver = BrowserConfig.driver;
	public TeamManagememtPage teamManagementPage;
	public LoginPage loginPage;
	public TeamManagement() {
		teamManagementPage = new TeamManagememtPage(driver);
		//loginPage = new LoginPage(driver);
	}
	
	
	

	@When("^I Navigate to Team Account$")
	public void i_Navigate_to_Team_Account() throws Throwable {
		teamManagementPage.navigateToTeamManagement("kelvina.persona6@test.com");
	}

	@When("^I Click on Create New Account$")
	public void i_Click_on_Create_New_Account() throws Throwable {
		teamManagementPage.clickOnCreateANewTeam();
	}

	@Then("^I Create a New Account$")
	public void i_Create_a_New_Account() throws Throwable {
		teamManagementPage.createNewTeam("Test Mobile Team 4");	
	}
	
	@Then("^I delete a Team Account$")
	public void i_delete_a_Team_Account() throws Throwable {
		teamManagementPage.deleteTeam();
	}

}
