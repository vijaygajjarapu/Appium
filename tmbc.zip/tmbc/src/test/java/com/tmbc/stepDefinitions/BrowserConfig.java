package com.tmbc.stepDefinitions;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;

import org.junit.After;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.interactions.touch.TouchActions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.ChartLocation;
import com.aventstack.extentreports.reporter.configuration.Theme;

import cucumber.api.java.Before;

import org.openqa.selenium.remote.*;

import io.appium.java_client.*;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.remote.AndroidMobileCapabilityType;
import io.appium.java_client.remote.MobileCapabilityType;
import io.appium.java_client.touch.WaitOptions;
import io.appium.java_client.touch.offset.PointOption;

import static io.appium.java_client.touch.WaitOptions.waitOptions;
import static io.appium.java_client.touch.offset.ElementOption.element;
import static io.appium.java_client.touch.offset.PointOption.point;
public class BrowserConfig {

	
	public static AppiumDriver driver = null;
	
	@Before
	public void beforeScenario() throws Throwable {
		 AndroidChrome_startRemoteDriver();		
	}
	
	@After
	public void afterScenario() throws Throwable {
		 driver.quit();		
	}
	
	
	public void AndroidChrome_startRemoteDriver() throws Throwable {
		
		String androidNodeUrl = "http://0.0.0.0:4723/wd/hub";
		DesiredCapabilities capabilities = new DesiredCapabilities();
		capabilities.setCapability("noReset", "true");
		
		capabilities.setCapability("fullReset", "false");
		capabilities.setCapability("platformName","Android" );
		capabilities.setCapability("platformVersion", "9.0");
		capabilities.setCapability("deviceName", "Android");
		capabilities.setCapability(MobileCapabilityType.UDID, "emulator-5554");
		/*capabilities.setCapability("newCommandTimeout", 2147482);
		capabilities.setCapability("unicodeKeyboard", true);
		capabilities.setCapability("resetKeyboard", true);
		capabilities.setCapability("autoAcceptAlerts", true);*/
		//capabilities.setCapability("chromedriverExecutable", "C:\\Users\\kelvina\\Music\\tmbc\\Drivers\\chromedriver.exe");		
		//capabilities.setCapability("appPackage", "com.android.calculator2");
		//capabilities.setCapability("appActivity", "com.android.calculator2.Calculator");
		capabilities.setCapability("appPackage", "io.appium.android.apis");
		capabilities.setCapability("appActivity", "io.appium.android.apis.ApiDemos");
		capabilities.setCapability("automationName", "uiautomator2");
		capabilities.setCapability(AndroidMobileCapabilityType.AUTO_GRANT_PERMISSIONS,true);
		capabilities.setCapability(MobileCapabilityType.APP,"C:\\Users\\vijay gajjarapu\\Downloads\\ApiDemos-debug.apk");
		//String cmd = "adb shell getprop ro.build.version.release";
		//String osVersions = executeCommand(cmd);

		/*if (osVersions.contains("9")) {
			// uninstall io.appium.settings
			cmd = "adb uninstall  io.appium.settings";
			executeCommand(cmd);
			// uninstall io.appium.unlock
			cmd = "adb uninstall  io.appium.unlock";
			executeCommand(cmd);
		}*/

		//System.setProperty("webdriver.chrome.driver","C:\\Users\\kelvina\\Music\\tmbc\\Drivers\\chromedriver.exe");
		driver = new AndroidDriver <MobileElement> (new URL(androidNodeUrl), capabilities);	
		Thread.sleep(6000);
		}
	
	
	
	public static String executeCommand(String cmd) {
		String commandresponse = "";
		try {
			Runtime run = Runtime.getRuntime();
			Process proc = run.exec(cmd);
			BufferedReader stdInput = new BufferedReader(new InputStreamReader(proc.getInputStream()));

			BufferedReader stdError = new BufferedReader(new InputStreamReader(proc.getErrorStream()));

			String response = null;
			while ((response = stdInput.readLine()) != null) {
				if (response.length() > 0) {
					commandresponse = commandresponse + response;
				}
			}

			while ((response = stdError.readLine()) != null) {
				commandresponse = commandresponse + response;

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		// System.out.println(commandresponse);
		return commandresponse;
	}

}
