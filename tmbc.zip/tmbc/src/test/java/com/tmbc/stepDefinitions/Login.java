package com.tmbc.stepDefinitions;

import org.openqa.selenium.WebDriver;

import com.tmbc.pages.LoginPage;
import com.tmbc.pages.TeamManagememtPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import io.appium.java_client.AppiumDriver;

public class Login {
	public static WebDriver driver = BrowserConfig.driver;
	public LoginPage loginPage;
	public Login() {
		loginPage = new LoginPage(driver);
	}
	
	@Then("^I log into application$")
	public void i_log_into_application() throws Throwable {
		/*loginPage.enterEmail("kelvina.persona6@test.com");
		loginPage.clickOnNextButton();
		loginPage.enterPassword("$Coconut!");
		loginPage.clickLogin();*/
		loginPage.navigateToHello();
		//loginPage.calc();
	}
	
	@Given("^I start the Chrome Remote driver on mobile$")
	public void i_start_the_Chrome_Remote_driver_on_mobile() throws Throwable {
	    
	}

	@Given("^I navigated to More Menu Screen$")
	public void i_navigated_to_More_Menu_Screen() throws Throwable {
		loginPage.clickOnMoreMenu();
	}

	@Then("^I log out of application$")
	public void i_log_out_of_application() throws Throwable {
		loginPage.logout();	
	}
}
