package com.runnerclass;

import org.junit.runner.JUnitCore;
import org.junit.runner.Result;
import org.junit.runner.RunWith;
import org.junit.runner.notification.Failure;

import com.tmbc.stepDefinitions.*;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)

@CucumberOptions(plugin = { "pretty:STDOUT", "html:format","pretty", "json:target/cucumber.json",
		"html:target/index.html" }, features = {"src/test/resources/com/tmbc/features"}, tags = {
				"@Login1" },glue = { "com.tmbc.stepDefinitions" })

public class RunnerClassTest {	
	
}
